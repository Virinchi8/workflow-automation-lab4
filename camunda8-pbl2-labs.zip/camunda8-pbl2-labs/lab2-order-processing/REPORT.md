# Lab 2 - End-to-End E-Commerce Order Processing and Fulfilment

**Course:** PBL-II - Camunda 8 workflow automation  
**Student:** _your name_  **Register no.:** _your register number_  
**Date:** _submission date_

## 1. Objective

Implement the *End-to-End E-Commerce Order Processing and Fulfilment* workflow on Camunda 8 using BPMN for orchestration, a DMN decision table for the business rules, Spring Boot external job workers, a REST connector calling a mock service, Tasklist for human work, and Operate for monitoring and incident recovery. All data is synthetic.

## 2. Architecture

```mermaid
flowchart LR
  M[Camunda Modeler<br/>BPMN, DMN, forms] -- deploy --> Z
  subgraph C8[Camunda 8 cluster]
    Z[Zeebe engine]
    O[Operate]
    T[Tasklist]
    CR[Connectors runtime<br/>REST connector]
  end
  Z <-- job workers poll / complete --> W[Spring Boot application :8082<br/>job workers]
  CR -- HTTP --> API[Mock REST API<br/>same Spring Boot application]
  U[Staff user] --> T
  Z --> O
```

* **Models** - `bpmn/order-processing.bpmn`, `dmn/order-priority.dmn`, `forms/*.form`; deployed automatically when the Spring Boot application starts (`@Deployment`) or manually from Camunda Modeler.
* **Worker application** (`worker/`, package `com.pbl2.lab2`) - hosts the job workers and the mock REST API so that one process runs everything locally.
* **REST connector** - a service task of type `io.camunda:http-json:1`, executed by the connectors runtime of the cluster.
* **Failure switches** - runtime flags (`/admin/switches`) used to cause and then repair failures for the incident scenarios.

## 3. Process design and execution flow

```mermaid
flowchart TD
    S([Order received]) --> V[Validate order<br/>worker: validate-order]
    V --> G1{Order valid?}
    G1 -- No --> RI([Order rejected])
    G1 -- Yes --> I[Check inventory<br/>worker: check-inventory]
    I --> G2{Stock available?}
    G2 -- No --> OOS([Out of stock])
    G2 -- Yes --> T[Calculate order total<br/>worker: calculate-total]
    T --> P[Determine priority<br/>DMN orderPriority]
    P --> G3{High-value order?<br/>total >= 100000}
    G3 -- Yes --> VO[Verify high-value order<br/>user task]
    VO --> G4{Verified?}
    G4 -- Rejected --> RV([Rejected by verifier])
    G4 -- Approved --> PAY
    G3 -- No --> PAY[Process payment<br/>REST connector]
    PAY --> G5{Payment approved?}
    G5 -- No --> PD([Payment declined])
    G5 -- Yes --> F[Create fulfilment<br/>worker: fulfil-order]
    F --> OK([Order sent to fulfilment])
```

### Gateway routing

| Gateway / event | Condition | Route |
|---|---|---|
| Order valid? | `orderValid = false` | No -> Mark REJECTED_INVALID -> *Order rejected (invalid)* |
| Order valid? | default | Yes -> Check inventory |
| Stock available? | `stockAvailable = false` | No -> Mark OUT_OF_STOCK -> *Out of stock: not fulfilled* |
| Stock available? | default | Yes -> Calculate order total -> Determine priority (DMN) |
| High-value order? | `orderTotal >= 100000` | Yes -> Verify high-value order (user task) |
| High-value order? | default | No -> Process payment |
| Verified? | `verificationDecision = "APPROVED"` | Approved -> Process payment |
| Verified? | default | Rejected -> Mark REJECTED_BY_REVIEW -> *Rejected by verifier* |
| Payment approved? | `paymentStatus = "APPROVED"` | Yes -> Create fulfilment -> Mark FULFILLED -> *Order sent to fulfilment* |
| Payment approved? | default | No -> Mark PAYMENT_DECLINED -> *Payment declined* |

## 4. Decision model (DMN)

See [docs/dmn-rules.md](docs/dmn-rules.md) for the inputs, outputs, every rule and sample evaluations. The decision is invoked by a business rule task and its result is stored in a process variable that the following gateway reads.

## 5. Implementation

### External job workers

| Job type | Method | Purpose |
|---|---|---|
| validate-order | `OrderWorkers.validateOrder` | Validates the order fields and synthetic payment token, looks up product and customer category, generates the order id. |
| check-inventory | `OrderWorkers.checkInventory` | Checks the simulated stock level. |
| calculate-total | `OrderWorkers.calculateTotal` | Computes subtotal, 18 % tax, shipping and the order total. |
| fulfil-order | `OrderWorkers.fulfilOrder` | Reserves stock and creates the fulfilment record (after payment is approved). |

Workers return a `Map` that Camunda merges into the process variables when the job completes. Throwing an exception fails the job; the BPMN sets `retries="1"`, so a single failure creates an incident that can be retried from Operate after the cause is fixed.

### REST connector

| Setting | Value |
|---|---|
| Task definition type | `io.camunda:http-json:1` (REST outbound connector) |
| Authentication | `noAuth` (mock service, synthetic tokens only) |
| Method / URL | `POST` `http://localhost:8082/mock/payments` |
| Body (FEEL) | `={orderId: orderId, paymentToken: paymentToken, amount: orderTotal, currency: "INR"}` |
| Timeouts | connection 5 s, read 10 s |
| Result expression | `={paymentStatus: response.body.status, transactionId: response.body.transactionId, declineReason: response.body.declineReason}` |
| Error expression | none - an HTTP 5xx response makes the connector job fail, which raises an incident (the *service failure* scenario) |
| Retries / backoff | retries = 1 (`zeebe:taskDefinition`), `retryBackoff = PT0S` |

### Forms (Tasklist)

| Form id | Used for |
|---|---|
| order-start | Start form in Tasklist - Processes |
| order-verification | High-value order verification user task |

### Process variables

The complete dictionary (name, type, producer, purpose) is in [docs/process-variables.md](docs/process-variables.md).

## 6. Test scenarios and results

The test-case table with inputs, expected route, actual outcome and status is in [docs/test-cases.md](docs/test-cases.md). Results read back from the running cluster are written to `docs/test-results.md` by `scripts/run_test_cases.py`. The screenshots listed in [docs/screenshots/README.md](docs/screenshots/README.md) are the evidence for deployment, Tasklist work and Operate monitoring.

**Status of evidence:** _fill in after running - results table pasted / linked, screenshots added to `docs/screenshots/`._

## 7. Incident investigation and recovery

Failure switches available in this lab:

| Switch | Effect |
|---|---|
| payment-outage | mock payment API answers HTTP 503 -> incident on **Process payment** |
| inventory-failure | `check-inventory` throws -> incident on **Check inventory** |

Procedure used for each incident scenario:

1. Turn the switch ON (`scripts/run_test_cases.py 2 --case <id>` does this) and start the instance.
2. In **Operate** open the instance, select the failed element and read the incident error message (screenshot).
3. Fix the cause: `python scripts/run_test_cases.py 2 --recover` (or call the admin endpoint).
4. In Operate press **Retry** on the incident; the job is re-activated, succeeds and the instance continues to its end event (screenshots).

## 8. Assumptions and limitations

* All business rules, thresholds, prices and interest rates are illustrative values chosen for the exercise.
* The mock APIs keep state in memory only; restarting the worker application resets it.
* Failure switches are a teaching aid - a real service would fail for real reasons.
* Authentication is disabled (local Camunda 8 Run); a production setup would secure the cluster, the worker credentials and the APIs.
* The REST connector calls `localhost`; this works when the connectors runtime runs on the same machine as the worker application (Camunda 8 Run). With Docker Compose use `host.docker.internal` in the URL.
* Retries are set to 1 so incidents appear immediately; production processes would use retries with back-off.

## 9. How to run

See [README.md](README.md) in this folder and [../docs/SETUP.md](../docs/SETUP.md).
