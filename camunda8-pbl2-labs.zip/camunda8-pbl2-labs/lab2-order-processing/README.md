# Lab 2 - End-to-End E-Commerce Order Processing and Fulfilment

## Contents

| Path | What it is |
|---|---|
| bpmn/order-processing.bpmn | BPMN process `order-processing` |
| dmn/order-priority.dmn | DMN decision table |
| forms/ | Camunda Forms for the start form and the user tasks |
| worker/ | Spring Boot application: job workers + mock REST API (port 8082) + unit tests |
| test-data/test-cases.json | Machine-readable test cases used by `scripts/run_test_cases.py` |
| REPORT.md | Implementation report |
| docs/ | process-variables, DMN rules, REST/API examples, test cases, screenshots checklist |

## Run it

1. Start a local Camunda 8 cluster (see [../docs/SETUP.md](../docs/SETUP.md)).
2. Start the worker application (deploys the models automatically):

```bash
cd worker
mvn spring-boot:run
```
3. Open Tasklist / Operate (`http://localhost:8080/tasklist`, `http://localhost:8080/operate`, login `demo` / `demo`).
4. Start instances - either with the *End* start form in Tasklist -> Processes, or:

```bash
python ../scripts/run_test_cases.py 2              # all non-incident cases
python ../scripts/run_test_cases.py 2 --case TC-L2-08   # one case (an incident case)
python ../scripts/run_test_cases.py 2 --recover            # switch failures OFF, then Retry in Operate
python ../scripts/run_test_cases.py 2 --collect            # write docs/test-results.md
```
5. Complete the human tasks in Tasklist, inspect the instances in Operate and capture the screenshots listed in [docs/screenshots/README.md](docs/screenshots/README.md).

Unit tests of the business logic (no Camunda needed): `cd worker && mvn test`.
