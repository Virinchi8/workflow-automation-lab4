# Lab 2 - process-variable dictionary

| Variable | Type | Set by | Purpose |
|---|---|---|---|
| customerRef | string | start form / API | Synthetic customer reference (`CUST-STD-01`, `CUST-PRM-01`, `CUST-VIP-01`) |
| productId | string | start form / API | `P-1001` .. `P-1004` (catalogue in `OrderService`) |
| quantity | number | start form / API | 1-50 |
| deliveryPreference | string | start form / API | `STANDARD` or `EXPRESS` |
| paymentToken | string | start form / API | Synthetic token starting `tok_` (never a real card number) |
| orderId | string | worker `validate-order` | Generated order id, also sent to the payment API |
| orderValid | boolean | worker `validate-order` | Routing flag for gateway *Order valid?* |
| validationErrors | list of string | worker `validate-order` | Reasons when the order is invalid |
| productName | string | worker `validate-order` | Catalogue lookup |
| unitPrice | number | worker `validate-order` | Catalogue price in INR |
| customerCategory | string | worker `validate-order` | `STANDARD` / `PREMIUM` / `VIP` (DMN input) |
| availableQuantity | number | worker `check-inventory` | Simulated stock on hand |
| stockAvailable | boolean | worker `check-inventory` | Routing flag for gateway *Stock available?* |
| subtotal | number | worker `calculate-total` | unitPrice x quantity |
| taxAmount | number | worker `calculate-total` | 18 % of subtotal |
| shippingCharge | number | worker `calculate-total` | EXPRESS 250; STANDARD free from 1000, else 99 |
| orderTotal | number | worker `calculate-total` | subtotal + tax + shipping (DMN input, payment amount, high-value test) |
| priorityResult | context | DMN `orderPriority` | `{priority, slaHours}` |
| verificationDecision | string | form `order-verification` | `APPROVED` or `REJECTED` |
| verificationNotes | string | form `order-verification` | Free text |
| paymentStatus | string | REST connector (result expression) | `APPROVED` or `DECLINED` |
| transactionId | string | REST connector | Mock transaction id (null when declined) |
| declineReason | string | REST connector | e.g. `INSUFFICIENT_FUNDS`, `CARD_EXPIRED` |
| fulfilmentId | string | worker `fulfil-order` | Generated fulfilment id |
| fulfilmentStatus | string | worker `fulfil-order` | `QUEUED_FOR_PICKING` |
| deliveryPriority | string | worker `fulfil-order` | Copied from `priorityResult.priority` |
| fulfilmentSlaHours | number | worker `fulfil-order` | Copied from `priorityResult.slaHours` |
| finalStatus | string | script task | `FULFILLED`, `OUT_OF_STOCK`, `PAYMENT_DECLINED`, `REJECTED_INVALID`, `REJECTED_BY_REVIEW` |
