# Lab 2 - REST connector configuration and API examples

## REST connector configuration

Task **Process payment (POST /mock/payments)** in `bpmn/order-processing.bpmn`. In Camunda Modeler this appears as a service task with the REST outbound connector settings below (select the task -> *Input / Output* and *Headers* in the properties panel, or apply the *REST Outbound Connector* template).

| Setting | Value |
|---|---|
| Task definition type | `io.camunda:http-json:1` (REST outbound connector) |
| Authentication | `noAuth` (mock service, synthetic tokens only) |
| Method / URL | `POST` `http://localhost:8082/mock/payments` |
| Body (FEEL) | `={orderId: orderId, paymentToken: paymentToken, amount: orderTotal, currency: "INR"}` |
| Timeouts | connection 5 s, read 10 s |
| Result expression | `={paymentStatus: response.body.status, transactionId: response.body.transactionId, declineReason: response.body.declineReason}` |
| Error expression | none - an HTTP 5xx response makes the connector job fail, which raises an incident (the *service failure* scenario) |
| Retries / backoff | retries = 1 (`zeebe:taskDefinition`), `retryBackoff = PT0S` |

## Request / response examples

All examples run against the mock payment API of this lab (worker application on port 8082); they work without Camunda.

### 1. Payment approved (HTTP 200)

```bash
curl -s -X POST http://localhost:8082/mock/payments \
  -H 'Content-Type: application/json' \
  -d '{"orderId":"ORD-2001","paymentToken":"tok_visa_ok","amount":2832.0,"currency":"INR"}'
```

```json
{"orderId":"ORD-2001","status":"APPROVED","transactionId":"TXN-9001","declineReason":null}
```

### 2. Payment declined (HTTP 200)

```bash
curl -s -X POST http://localhost:8082/mock/payments \
  -H 'Content-Type: application/json' \
  -d '{"orderId":"ORD-2003","paymentToken":"tok_declined","amount":4130.0,"currency":"INR"}'
```

```json
{"orderId":"ORD-2003","status":"DECLINED","transactionId":null,"declineReason":"INSUFFICIENT_FUNDS"}
```

Other behaviours: `tok_expired` -> `CARD_EXPIRED`; amount above 500000 -> `LIMIT_EXCEEDED`.

### 3. Payment service outage (HTTP 503)

```bash
curl -s -X POST 'http://localhost:8082/admin/switches/payment-outage?enabled=true'
curl -s -i -X POST http://localhost:8082/mock/payments -H 'Content-Type: application/json' \
  -d '{"orderId":"ORD-2007","paymentToken":"tok_visa_ok","amount":4130.0,"currency":"INR"}'
```

```json
{"error":"PAYMENT_GATEWAY_UNAVAILABLE"}
```

### 4. Admin API

```bash
curl -s http://localhost:8082/admin/switches
curl -s -X POST 'http://localhost:8082/admin/switches/inventory-failure?enabled=true'
curl -s http://localhost:8082/admin/inventory
curl -s -X POST http://localhost:8082/admin/inventory/reset
curl -s -X POST http://localhost:8082/admin/reset
```

### 5. Start a process instance (Camunda REST API v2)

```bash
curl -s -X POST http://localhost:8080/v2/process-instances \
  -H 'Content-Type: application/json' \
  -d '{"processDefinitionId":"order-processing","variables":{
        "customerRef":"CUST-STD-01","productId":"P-1002","quantity":2,
        "deliveryPreference":"STANDARD","paymentToken":"tok_visa_ok"}}'
```
