# Order priority decision table

Decision table file: `dmn/order-priority.dmn`  
Hit policy: **FIRST** (the first rule, top to bottom, whose conditions all match wins).  
A dash (`-`) means "any value".

## Inputs and outputs

| # | Input | FEEL input expression |
|---|---|---|
| 1 | Order total (INR) | `orderTotal` |
| 2 | Customer category | `customerCategory` |
| 3 | Delivery preference | `deliveryPreference` |

| # | Output name | Label |
|---|---|---|
| 1 | priority | Priority |
| 2 | slaHours | Fulfilment SLA (hours) |

## Rules

| Rule | Order total (INR) | Customer category | Delivery preference | -> priority | -> slaHours |
|---|---|---|---|---|---|
| R1 - VIP customers always HIGH | `-` | `"VIP"` | `-` | `"HIGH"` | `4` |
| R2 - Express and order total >= 10000 | `>= 10000` | `-` | `"EXPRESS"` | `"HIGH"` | `4` |
| R3 - Any other express order | `-` | `-` | `"EXPRESS"` | `"MEDIUM"` | `24` |
| R4 - Premium customers | `-` | `"PREMIUM"` | `-` | `"MEDIUM"` | `24` |
| R5 - Large standard orders | `>= 50000` | `-` | `-` | `"MEDIUM"` | `24` |
| R6 - Everything else | `-` | `-` | `-` | `"LOW"` | `72` |

## Sample evaluations

Evaluated against the rules in the `.dmn` file above (not typed by hand).

| Scenario | Inputs | Matched rule | Result | Detail |
|---|---|---|---|---|
| VIP, small standard order | total 2832, VIP, STANDARD | R1 | HIGH | SLA 4 h |
| Express, total 12000 | total 12000, STANDARD, EXPRESS | R2 | HIGH | SLA 4 h |
| Express, total 4130 | total 4130, STANDARD, EXPRESS | R3 | MEDIUM | SLA 24 h |
| Premium customer, standard delivery | total 2832, PREMIUM, STANDARD | R4 | MEDIUM | SLA 24 h |
| Standard customer, total 76700 | total 76700, STANDARD, STANDARD | R5 | MEDIUM | SLA 24 h |
| Standard customer, total 2832 | total 2832, STANDARD, STANDARD | R6 | LOW | SLA 72 h |
