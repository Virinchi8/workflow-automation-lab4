# Lab 2 - screenshots (evidence)

The assignment requires screenshots captured **from your own running implementation**. This folder is intentionally empty: take the screenshots listed below while you run the lab and save them here with these exact file names so the report links match. Do not submit placeholder images.

| File | What to capture | Where |
|---|---|---|
| 01-bpmn-model.png | The BPMN diagram open in Camunda Modeler | Modeler |
| 02-dmn-priority-table.png | The `orderPriority` decision table | Modeler |
| 03-rest-connector-config.png | Properties panel of the *Process payment* task | Modeler |
| 04-worker-running.png | Terminal showing the Spring Boot application started and deployment log | Terminal |
| 05-operate-processes.png | Operate -> Processes showing `order-processing` with several instances | Operate |
| 06-operate-fulfilled-instance.png | Operate: completed instance TC-L2-01 (stock OK, payment approved) | Operate |
| 07-operate-out-of-stock.png | Operate: TC-L2-02 ending in *Out of stock* | Operate |
| 08-operate-payment-declined.png | Operate: TC-L2-03 ending in *Payment declined* with variables | Operate |
| 09-tasklist-verification.png | Tasklist: *Verify high-value order* task and form (TC-L2-04) | Tasklist |
| 10-operate-variables.png | Operate: Variables tab showing orderTotal, priorityResult, paymentStatus | Operate |
| 11-operate-incident.png | Operate: incident on *Process payment* (TC-L2-07) | Operate |
| 12-incident-fixed-retry.png | Operate: incident resolved after `--recover` + *Retry* | Operate |
| 13-operate-recovered-instance.png | Operate: TC-L2-07 completed after recovery | Operate |

Tick each item once the file exists:

- [ ] `01-bpmn-model.png`
- [ ] `02-dmn-priority-table.png`
- [ ] `03-rest-connector-config.png`
- [ ] `04-worker-running.png`
- [ ] `05-operate-processes.png`
- [ ] `06-operate-fulfilled-instance.png`
- [ ] `07-operate-out-of-stock.png`
- [ ] `08-operate-payment-declined.png`
- [ ] `09-tasklist-verification.png`
- [ ] `10-operate-variables.png`
- [ ] `11-operate-incident.png`
- [ ] `12-incident-fixed-retry.png`
- [ ] `13-operate-recovered-instance.png`
