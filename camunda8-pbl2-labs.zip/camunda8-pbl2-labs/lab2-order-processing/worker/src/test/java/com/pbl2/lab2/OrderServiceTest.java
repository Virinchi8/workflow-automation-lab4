package com.pbl2.lab2;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.pbl2.lab2.service.InventoryService;
import com.pbl2.lab2.service.OrderService;
import java.util.HashMap;
import java.util.Map;
import org.junit.jupiter.api.Test;

class OrderServiceTest {

    private final OrderService service = new OrderService();

    private Map<String, Object> order() {
        Map<String, Object> v = new HashMap<>();
        v.put("customerRef", "CUST-PRM-01");
        v.put("productId", "P-1001");
        v.put("quantity", 2);
        v.put("deliveryPreference", "EXPRESS");
        v.put("paymentToken", "tok_visa_ok");
        return v;
    }

    @Test
    void validOrderIsEnriched() {
        OrderService.Validation v = service.validate(order());
        assertTrue(v.valid());
        assertEquals(65000.0, v.unitPrice(), 0.001);
        assertEquals("PREMIUM", v.customerCategory());
    }

    @Test
    void cardLikeTokenIsRejected() {
        Map<String, Object> o = order();
        o.put("paymentToken", "tok_4111111111111111");
        assertFalse(service.validate(o).valid());
    }

    @Test
    void unknownProductAndZeroQuantityAreReported() {
        Map<String, Object> o = order();
        o.put("productId", "P-9999");
        o.put("quantity", 0);
        OrderService.Validation v = service.validate(o);
        assertFalse(v.valid());
        assertEquals(2, v.errors().size());
    }

    @Test
    void totalsForHighValueExpressOrder() {
        OrderService.Totals t = service.total(65000, 2, "EXPRESS");
        assertEquals(130000.0, t.subtotal(), 0.001);
        assertEquals(23400.0, t.taxAmount(), 0.001);
        assertEquals(250.0, t.shippingCharge(), 0.001);
        assertEquals(153650.0, t.orderTotal(), 0.001);
    }

    @Test
    void smallStandardOrderPaysShipping() {
        OrderService.Totals t = service.total(500, 1, "STANDARD");
        assertEquals(99.0, t.shippingCharge(), 0.001);
        assertEquals(689.0, t.orderTotal(), 0.001);
    }

    @Test
    void customerCategoryIsDerivedFromReference() {
        assertEquals("VIP", OrderService.categoryFor("CUST-VIP-01"));
        assertEquals("PREMIUM", OrderService.categoryFor("CUST-PRM-01"));
        assertEquals("STANDARD", OrderService.categoryFor("CUST-STD-01"));
    }

    @Test
    void inventoryReserveAndReset() {
        InventoryService inventory = new InventoryService();
        assertTrue(inventory.reserve("P-1003", 5));
        assertFalse(inventory.reserve("P-1003", 1));
        assertEquals(0, inventory.available("P-1003"));
        inventory.reset();
        assertEquals(5, inventory.available("P-1003"));
    }
}
