package com.pbl2.lab2.worker;

import com.pbl2.lab2.config.FailureSwitches;
import com.pbl2.lab2.service.InventoryService;
import com.pbl2.lab2.service.OrderService;
import com.pbl2.lab2.util.Vars;
import io.camunda.client.annotation.JobWorker;
import io.camunda.client.api.response.ActivatedJob;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/** External job workers for the order-processing process. */
@Component
public class OrderWorkers {

    private static final Logger log = LoggerFactory.getLogger(OrderWorkers.class);

    private final OrderService orders;
    private final InventoryService inventory;
    private final FailureSwitches switches;
    private final AtomicLong orderSequence = new AtomicLong(2000);
    private final AtomicLong fulfilmentSequence = new AtomicLong(5000);

    public OrderWorkers(OrderService orders, InventoryService inventory, FailureSwitches switches) {
        this.orders = orders;
        this.inventory = inventory;
        this.switches = switches;
    }

    /** Validates the order fields and enriches it with product and customer data. */
    @JobWorker(type = "validate-order")
    public Map<String, Object> validateOrder(final ActivatedJob job) {
        OrderService.Validation v = orders.validate(job.getVariablesAsMap());
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("orderId", "ORD-" + orderSequence.incrementAndGet());
        out.put("orderValid", v.valid());
        out.put("validationErrors", v.errors());
        out.put("productName", v.productName());
        out.put("unitPrice", v.unitPrice());
        out.put("customerCategory", v.customerCategory());
        log.info("Validated order {}: valid={} errors={}", out.get("orderId"), v.valid(), v.errors());
        return out;
    }

    /** Checks simulated stock. Failing it on purpose (switch inventory-failure) demonstrates an incident. */
    @JobWorker(type = "check-inventory")
    public Map<String, Object> checkInventory(final ActivatedJob job) {
        if (switches.isOn("inventory-failure")) {
            throw new IllegalStateException(
                    "Simulated inventory-service failure (failure switch 'inventory-failure' is ON)");
        }
        Map<String, Object> vars = job.getVariablesAsMap();
        String productId = Vars.str(vars, "productId");
        int wanted = Vars.num(vars, "quantity").intValue();
        int available = inventory.available(productId);
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("availableQuantity", available);
        out.put("stockAvailable", available >= wanted);
        log.info("Stock check {} wanted={} available={}", productId, wanted, available);
        return out;
    }

    /** Calculates subtotal, tax, shipping and the order total. */
    @JobWorker(type = "calculate-total")
    public Map<String, Object> calculateTotal(final ActivatedJob job) {
        Map<String, Object> vars = job.getVariablesAsMap();
        OrderService.Totals t = orders.total(Vars.num(vars, "unitPrice"), Vars.num(vars, "quantity").intValue(),
                Vars.str(vars, "deliveryPreference"));
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("subtotal", t.subtotal());
        out.put("taxAmount", t.taxAmount());
        out.put("shippingCharge", t.shippingCharge());
        out.put("orderTotal", t.orderTotal());
        return out;
    }

    /** Reserves stock and creates the fulfilment record once payment has been approved. */
    @JobWorker(type = "fulfil-order")
    public Map<String, Object> fulfilOrder(final ActivatedJob job) {
        Map<String, Object> vars = job.getVariablesAsMap();
        String productId = Vars.str(vars, "productId");
        int qty = Vars.num(vars, "quantity").intValue();
        if (!inventory.reserve(productId, qty)) {
            throw new IllegalStateException("Stock for " + productId + " ran out before fulfilment");
        }
        Map<String, Object> priority = Vars.map(vars, "priorityResult");
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("fulfilmentId", "FUL-" + fulfilmentSequence.incrementAndGet());
        out.put("fulfilmentStatus", "QUEUED_FOR_PICKING");
        out.put("deliveryPriority", priority.getOrDefault("priority", "LOW"));
        out.put("fulfilmentSlaHours", priority.getOrDefault("slaHours", 72));
        return out;
    }
}
