package com.pbl2.lab2.service;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.springframework.stereotype.Component;

/** Simulated in-memory stock levels. Restart the application or call /admin/inventory/reset to restore them. */
@Component
public class InventoryService {

    private static final Map<String, Integer> INITIAL = Map.of(
            "P-1001", 20, "P-1002", 200, "P-1003", 5, "P-1004", 50);

    private final Map<String, Integer> stock = new ConcurrentHashMap<>(INITIAL);

    public int available(String productId) {
        return stock.getOrDefault(productId, 0);
    }

    /** Atomically removes the quantity from stock; returns false if there is not enough. */
    public boolean reserve(String productId, int quantity) {
        boolean[] ok = {false};
        stock.computeIfPresent(productId, (id, current) -> {
            if (current >= quantity) {
                ok[0] = true;
                return current - quantity;
            }
            return current;
        });
        return ok[0];
    }

    public void reset() {
        stock.clear();
        stock.putAll(INITIAL);
    }

    public Map<String, Integer> snapshot() {
        return new LinkedHashMap<>(new java.util.TreeMap<>(stock));
    }
}
