package com.pbl2.lab2.config;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.springframework.stereotype.Component;

/**
 * Runtime "failure switches" used to demonstrate incidents and recovery. A switch is turned ON
 * through the admin API (POST /admin/switches/{name}?enabled=true) to break a worker or the mock
 * API, and turned OFF again to fix the cause before the incident is retried in Operate.
 */
@Component
public class FailureSwitches {

    public static final List<String> KNOWN = List.of("payment-outage", "inventory-failure");

    private final Map<String, Boolean> state = new ConcurrentHashMap<>();

    public FailureSwitches() {
        KNOWN.forEach(name -> state.put(name, false));
    }

    public boolean isOn(String name) {
        return state.getOrDefault(name, false);
    }

    public boolean set(String name, boolean enabled) {
        if (!state.containsKey(name)) {
            return false;
        }
        state.put(name, enabled);
        return true;
    }

    public void resetAll() {
        KNOWN.forEach(name -> state.put(name, false));
    }

    public Map<String, Boolean> snapshot() {
        return Map.copyOf(state);
    }
}
