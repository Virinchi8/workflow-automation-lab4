package com.pbl2.lab2.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Null-safe readers for process variables, which arrive as loosely typed JSON values. */
public final class Vars {

    private Vars() {
    }

    public static String str(Map<String, Object> vars, String key) {
        Object v = vars.get(key);
        return v == null ? null : String.valueOf(v);
    }

    public static Double num(Map<String, Object> vars, String key) {
        Object v = vars.get(key);
        if (v instanceof Number n) {
            return n.doubleValue();
        }
        if (v instanceof String s && !s.isBlank()) {
            try {
                return Double.parseDouble(s.trim());
            } catch (NumberFormatException e) {
                return null;
            }
        }
        return null;
    }

    public static List<String> strList(Map<String, Object> vars, String key) {
        List<String> out = new ArrayList<>();
        if (vars.get(key) instanceof List<?> list) {
            for (Object o : list) {
                if (o != null) {
                    out.add(String.valueOf(o));
                }
            }
        }
        return out;
    }

    @SuppressWarnings("unchecked")
    public static Map<String, Object> map(Map<String, Object> vars, String key) {
        return vars.get(key) instanceof Map<?, ?> m ? (Map<String, Object>) m : Map.of();
    }
}
