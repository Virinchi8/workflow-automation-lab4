package com.pbl2.lab2.service;

import com.pbl2.lab2.util.Vars;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.springframework.stereotype.Component;

/** Order validation and pricing rules. Free of Camunda types so it can be unit tested directly. */
@Component
public class OrderService {

    public record Product(String id, String name, double unitPrice) {
    }

    public record Validation(boolean valid, List<String> errors, String productName, double unitPrice,
                             String customerCategory) {
    }

    public record Totals(double subtotal, double taxAmount, double shippingCharge, double orderTotal) {
    }

    public static final double TAX_RATE = 0.18;
    public static final Set<String> DELIVERY = Set.of("STANDARD", "EXPRESS");

    private static final Map<String, Product> CATALOGUE = Map.of(
            "P-1001", new Product("P-1001", "Laptop 14in (synthetic)", 65000),
            "P-1002", new Product("P-1002", "Wireless Mouse (synthetic)", 1200),
            "P-1003", new Product("P-1003", "Monitor 24in (synthetic)", 15000),
            "P-1004", new Product("P-1004", "Keyboard (synthetic)", 3500));

    public Validation validate(Map<String, Object> v) {
        List<String> errors = new ArrayList<>();
        String customer = Vars.str(v, "customerRef");
        if (customer == null || !customer.matches("CUST-[A-Z0-9]+(-[A-Z0-9]+)*")) {
            errors.add("customerRef must look like CUST-STD-01");
        }
        Product product = CATALOGUE.get(Vars.str(v, "productId"));
        if (product == null) {
            errors.add("productId is not in the catalogue " + CATALOGUE.keySet().stream().sorted().toList());
        }
        Double qty = Vars.num(v, "quantity");
        if (qty == null || qty < 1 || qty > 50 || qty != Math.floor(qty)) {
            errors.add("quantity must be a whole number between 1 and 50");
        }
        String delivery = Vars.str(v, "deliveryPreference");
        if (delivery == null || !DELIVERY.contains(delivery)) {
            errors.add("deliveryPreference must be one of " + DELIVERY);
        }
        String token = Vars.str(v, "paymentToken");
        if (token == null || !token.startsWith("tok_")) {
            errors.add("paymentToken must be a synthetic token starting with tok_");
        } else if (token.matches(".*\\d{12,19}.*")) {
            errors.add("paymentToken looks like a card number - use synthetic tokens only");
        }
        if (!errors.isEmpty()) {
            return new Validation(false, errors, null, 0, categoryFor(customer));
        }
        return new Validation(true, errors, product.name(), product.unitPrice(), categoryFor(customer));
    }

    /** Simulated customer master data: the category is derived from the customer reference. */
    public static String categoryFor(String customerRef) {
        if (customerRef == null) {
            return "STANDARD";
        }
        if (customerRef.contains("VIP")) {
            return "VIP";
        }
        if (customerRef.contains("PRM")) {
            return "PREMIUM";
        }
        return "STANDARD";
    }

    public Totals total(double unitPrice, int quantity, String delivery) {
        double subtotal = unitPrice * quantity;
        double tax = Math.round(subtotal * TAX_RATE * 100) / 100.0;
        double shipping = "EXPRESS".equals(delivery) ? 250 : (subtotal >= 1000 ? 0 : 99);
        double total = Math.round((subtotal + tax + shipping) * 100) / 100.0;
        return new Totals(subtotal, tax, shipping, total);
    }
}
