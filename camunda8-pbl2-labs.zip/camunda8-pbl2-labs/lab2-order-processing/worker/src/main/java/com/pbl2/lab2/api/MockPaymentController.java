package com.pbl2.lab2.api;

import com.pbl2.lab2.config.FailureSwitches;
import com.pbl2.lab2.util.Vars;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Mock payment gateway called by the REST connector (POST /mock/payments). Only synthetic tokens are
 * accepted - no real card data is ever processed.
 *
 * <ul>
 *   <li>tok_visa_ok (any other tok_ value) - approved</li>
 *   <li>tok_declined - declined, INSUFFICIENT_FUNDS</li>
 *   <li>tok_expired - declined, CARD_EXPIRED</li>
 *   <li>amount above 500000 - declined, LIMIT_EXCEEDED</li>
 *   <li>switch "payment-outage" ON - HTTP 503 for every call (service failure scenario)</li>
 * </ul>
 */
@RestController
@RequestMapping("/mock")
public class MockPaymentController {

    private static final Logger log = LoggerFactory.getLogger(MockPaymentController.class);

    private final FailureSwitches switches;
    private final AtomicLong transactions = new AtomicLong(9000);

    public MockPaymentController(FailureSwitches switches) {
        this.switches = switches;
    }

    @PostMapping("/payments")
    public ResponseEntity<Map<String, Object>> pay(@RequestBody Map<String, Object> request) {
        Map<String, Object> body = new LinkedHashMap<>();
        if (switches.isOn("payment-outage")) {
            log.warn("Switch 'payment-outage' is ON - answering 503");
            body.put("error", "PAYMENT_GATEWAY_UNAVAILABLE");
            return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(body);
        }
        String token = Vars.str(request, "paymentToken");
        Double amount = Vars.num(request, "amount");
        if (token == null || amount == null || amount <= 0) {
            body.put("error", "paymentToken and a positive amount are required");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(body);
        }
        body.put("orderId", Vars.str(request, "orderId"));
        String declineReason = null;
        if ("tok_declined".equals(token)) {
            declineReason = "INSUFFICIENT_FUNDS";
        } else if ("tok_expired".equals(token)) {
            declineReason = "CARD_EXPIRED";
        } else if (!token.startsWith("tok_")) {
            declineReason = "INVALID_TOKEN";
        } else if (amount > 500_000) {
            declineReason = "LIMIT_EXCEEDED";
        }
        log.info("Payment for order {} amount {} token {} -> {}", request.get("orderId"), amount, token,
                declineReason == null ? "APPROVED" : "DECLINED (" + declineReason + ")");
        if (declineReason != null) {
            body.put("status", "DECLINED");
            body.put("transactionId", null);
            body.put("declineReason", declineReason);
        } else {
            body.put("status", "APPROVED");
            body.put("transactionId", "TXN-" + transactions.incrementAndGet());
            body.put("declineReason", null);
        }
        return ResponseEntity.ok(body);
    }
}
