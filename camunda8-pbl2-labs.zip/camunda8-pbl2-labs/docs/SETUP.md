# Setup guide

## Prerequisites

| Tool | Version | Notes |
|---|---|---|
| JDK | 17 or newer (21 recommended) | `java -version` |
| Maven | 3.9+ | `mvn -v` |
| Camunda 8 | 8.8 or newer | Self-Managed: **Camunda 8 Run** (single download) or Docker Compose |
| Camunda Modeler (Desktop) | 5.x | to open / edit `.bpmn`, `.dmn`, `.form`; set the target to Camunda 8.8+ |
| Python | 3.8+ | only for `scripts/run_test_cases.py` (standard library only) |

## 1. Start Camunda 8 locally

Follow the current instructions for your platform:

* Camunda 8 Run - <https://docs.camunda.io/docs/self-managed/quickstart/developer-quickstart/c8run/>
* Docker Compose - <https://docs.camunda.io/docs/self-managed/quickstart/developer-quickstart/docker-compose/>

When it is running you should be able to open:

* Operate - <http://localhost:8080/operate>
* Tasklist - <http://localhost:8080/tasklist>
* REST API - <http://localhost:8080/v2/topology> (no authentication by default for local development)

Default local login is `demo` / `demo`. The user tasks in the BPMN files are assigned to the user `demo` (and list a candidate group),
so they appear under *Assigned to me* in Tasklist. If you log in with another user, change the `assignee` of the user tasks in the BPMN.

The Camunda 8 Run distribution includes the **connectors runtime**, which executes the REST connector. It runs on your machine, so the
connector can call `http://localhost:808x/...`. If you use Docker Compose, replace `localhost` in the connector URL with
`host.docker.internal`. Camunda 8 SaaS cannot reach `localhost`.

## 2. Build and run a worker application

```bash
cd lab1-loan-approval/worker
mvn spring-boot:run          # or: mvn clean package && java -jar target/*.jar
```

On start-up the application:

1. connects to the cluster (`camunda.client.*` in `src/main/resources/application.yml`),
2. deploys `../bpmn/*.bpmn`, `../dmn/*.dmn`, `../forms/*.form` (see `@Deployment`),
3. registers the job workers and exposes the mock REST API and the admin API on its port (8081 / 8082 / 8083).

Configuration notes:

* `camunda.version` in `pom.xml` is the client version; keep it on the same minor line as your cluster (8.8.x or later).
* For a cluster that requires authentication set `camunda.client.auth.method` to `basic` (with `username` / `password`) or `oidc` - see
  <https://docs.camunda.io/docs/apis-tools/camunda-spring-boot-starter/configuration/>. Never commit credentials; use environment variables.
* To deploy from Camunda Modeler instead, open the files in `bpmn/`, `dmn/` and `forms/`, click *Deploy* and choose your local cluster.

## 3. Run the scenarios

```bash
python scripts/run_test_cases.py 1                  # start the non-incident cases of lab 1
python scripts/run_test_cases.py 1 --case TC-L1-07  # an incident case (sets its failure switch first)
python scripts/run_test_cases.py 1 --recover        # switch failures OFF, then press Retry in Operate
python scripts/run_test_cases.py 1 --collect        # write lab1-loan-approval/docs/test-results.md
```

Add `--user demo --password demo` if your cluster requires basic authentication, and `--base-url` if it is not on `localhost:8080`.

## 4. Manual REST examples

Each lab's `docs/rest-api-examples.md` contains `curl` commands for the mock API, the admin API and for starting an instance directly.

## Troubleshooting

| Symptom | Likely cause / fix |
|---|---|
| Worker never receives jobs | client cannot authenticate (check `camunda.client.auth.method`) or cluster not started; look at the application log |
| Models not deployed | models are copied from `../bpmn`, `../dmn`, `../forms` during the Maven build - run from the `worker` folder |
| REST connector task fails immediately with a connection error | worker application not running, wrong port, or the connectors runtime cannot reach `localhost` (Docker Compose: use `host.docker.internal`) |
| Task not visible in Tasklist | log in as the assignee (`demo`) or edit the assignee in the BPMN |
| `--collect` shows ERROR | the secondary storage (search index) may still be catching up - wait a few seconds and retry |
