# Submission checklist (assignment: Common Submission Checklist)

Tick the box once the item exists for **all three labs**.

| Done | Requirement | Where in this repository |
|---|---|---|
| ☐ | BPMN model files and screenshots of process design | `labN/bpmn/*.bpmn`, `labN/docs/screenshots/01-bpmn-model.png` |
| ☐ | DMN model files, rule descriptions and sample decision results | `labN/dmn/*.dmn`, `labN/docs/dmn-rules.md` |
| ☐ | External job worker source code and instructions to run it | `labN/worker/`, `labN/README.md`, `docs/SETUP.md` |
| ☐ | REST connector configuration and API examples | `labN/REPORT.md` (section 5), `labN/docs/rest-api-examples.md`, `labN/bpmn/*.bpmn` |
| ☐ | Process-variable dictionary (names, types, purpose) | `labN/docs/process-variables.md` |
| ☐ | Test cases covering successful, rejected, manual-review and failure/recovery paths | `labN/docs/test-cases.md`, `labN/test-data/test-cases.json` |
| ☐ | Evidence of model deployment and workflow instance execution | screenshots `04` - `07` of each lab, `labN/docs/test-results.md` |
| ☐ | Tasklist evidence for human tasks | `labN/docs/screenshots/*tasklist*.png` |
| ☐ | Operate evidence for monitoring and incident resolution | `labN/docs/screenshots/*operate*.png`, `*incident*.png` |
| ☐ | Short report explaining architecture, execution flow, results and limitations | `labN/REPORT.md` |

Lab-specific minimum scenarios (all are defined as test cases):

* **Lab 1** - approval, failed eligibility, manual review, credit API error / timeout, worker failure + recovery: `TC-L1-01` .. `TC-L1-08`
* **Lab 2** - stock + payment OK, insufficient stock, payment declined, high-value review, payment / inventory failure + recovery: `TC-L2-01` .. `TC-L2-08`
* **Lab 3** - routine with slot, priority review, urgent assessment, no slots, scheduling failure + recovery: `TC-L3-01` .. `TC-L3-07`

Safety rules from the assignment: synthetic data only; no real payment credentials, secrets or patient data in the repository;
screenshots must come from your own running implementation.
