#!/usr/bin/env python3
"""Start the documented test cases against a running Camunda 8 cluster and collect the outcomes.

Uses only the Python standard library. Typical session for lab 1:

    python scripts/run_test_cases.py 1                     # start every non-incident test case
    python scripts/run_test_cases.py 1 --case TC-L1-07     # start one case (sets its failure switch first)
    python scripts/run_test_cases.py 1 --recover           # switch every failure switch OFF again
    python scripts/run_test_cases.py 1 --collect           # read the results back and write docs/test-results.md

Human tasks are completed by you in Tasklist (that is part of the evidence); incidents are retried by
you in Operate. Run --collect again after you have finished those steps.

The Orchestration Cluster REST API (/v2/...) of Camunda 8.8 or newer is used. If your cluster is
secured, pass --user / --password (basic authentication).
"""
import argparse
import base64
import datetime
import json
import os
import sys
import urllib.error
import urllib.request

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LABS = {
    1: {"dir": "lab1-loan-approval", "process": "loan-approval", "port": 8081},
    2: {"dir": "lab2-order-processing", "process": "order-processing", "port": 8082},
    3: {"dir": "lab3-hospital-triage", "process": "patient-triage", "port": 8083},
}


def call(method, url, body=None, user=None, password=None, timeout=30):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Content-Type", "application/json")
    req.add_header("Accept", "application/json")
    if user:
        token = base64.b64encode(f"{user}:{password or ''}".encode()).decode()
        req.add_header("Authorization", f"Basic {token}")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode()
            return resp.status, (json.loads(raw) if raw else {})
    except urllib.error.HTTPError as exc:
        raw = exc.read().decode(errors="replace")
        try:
            return exc.code, json.loads(raw)
        except ValueError:
            return exc.code, {"raw": raw}
    except urllib.error.URLError as exc:
        sys.exit(f"Cannot reach {url}: {exc.reason}")


def load_cases(lab):
    path = os.path.join(REPO, LABS[lab]["dir"], "test-data", "test-cases.json")
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def runs_path(lab):
    return os.path.join(REPO, LABS[lab]["dir"], "test-data", "runs.json")


def load_runs(lab):
    try:
        with open(runs_path(lab), encoding="utf-8") as fh:
            return json.load(fh)
    except FileNotFoundError:
        return {}


def set_switches(lab, wanted, args):
    """Apply exactly the switches a case needs (all others OFF)."""
    admin = f"http://localhost:{LABS[lab]['port']}/admin"
    status, known = call("GET", f"{admin}/switches")
    if status != 200:
        sys.exit(f"Worker application not reachable on port {LABS[lab]['port']} (is it running?)")
    for name in known:
        call("POST", f"{admin}/switches/{name}?enabled={'true' if wanted.get(name) else 'false'}")


def start_case(lab, case, args):
    set_switches(lab, case.get("switches", {}), args)
    body = {"processDefinitionId": LABS[lab]["process"], "variables": case["variables"]}
    status, resp = call("POST", f"{args.base_url}/v2/process-instances", body, args.user, args.password)
    if status not in (200, 201):
        print(f"  {case['id']}: start failed (HTTP {status}): {resp}")
        return None
    key = str(resp.get("processInstanceKey"))
    print(f"  {case['id']}: started process instance {key}  - {case['title']}")
    if case.get("note"):
        print(f"      note: {case['note']}")
    return key


def search(path, filt, args):
    status, resp = call("POST", f"{args.base_url}/v2/{path}/search", {"filter": filt}, args.user, args.password)
    if status != 200:
        return None, f"HTTP {status} {resp}"
    return resp.get("items", []), None


def observe(key, args):
    obs = {"state": "?", "finalStatus": None, "incidents": [], "tasks": []}
    items, err = search("process-instances", {"processInstanceKey": key}, args)
    if err:
        obs["error"] = err
        return obs
    if items:
        obs["state"] = items[0].get("state", "?")
    items, _ = search("variables", {"processInstanceKey": key, "name": "finalStatus"}, args)
    if items:
        raw = items[0].get("value")
        try:
            obs["finalStatus"] = json.loads(raw) if isinstance(raw, str) else raw
        except ValueError:
            obs["finalStatus"] = raw
    items, _ = search("incidents", {"processInstanceKey": key}, args)
    obs["incidents"] = [(i.get("elementId"), i.get("state")) for i in (items or [])]
    items, _ = search("user-tasks", {"processInstanceKey": key}, args)
    obs["tasks"] = [(t.get("name") or t.get("elementId"), t.get("state")) for t in (items or [])]
    return obs


def judge(case, obs):
    exp = case["expect"]
    if obs.get("error"):
        return "ERROR", obs["error"]
    active_incident = [i for i in obs["incidents"] if i[1] == "ACTIVE"]
    waiting = [t for t in obs["tasks"] if t[1] == "CREATED"]
    if obs["state"] == "COMPLETED":
        if obs["finalStatus"] == exp.get("thenFinalStatus", exp.get("finalStatus")):
            return "PASS", f"completed, finalStatus = {obs['finalStatus']}"
        return "FAIL", f"completed with finalStatus = {obs['finalStatus']}, expected {exp.get('thenFinalStatus', exp.get('finalStatus'))}"
    if exp["kind"] == "user-task" and obs["state"] == "ACTIVE":
        if any(exp["taskName"] == t[0] for t in waiting):
            return "WAITING", f"waiting at user task '{exp['taskName']}' - complete it in Tasklist ({exp['thenDecision']}), then --collect again"
        return "FAIL", f"active but not at '{exp['taskName']}' (tasks: {obs['tasks']})"
    if exp["kind"] == "incident" and obs["state"] == "ACTIVE":
        if any(i[0] == exp["elementId"] for i in active_incident):
            return "WAITING", f"incident on {exp['elementId']} - fix the cause (--recover) and retry in Operate, then --collect again"
        return "FAIL", f"active, incidents: {obs['incidents']}"
    return "FAIL", f"state {obs['state']}, finalStatus {obs['finalStatus']}"


def collect(lab, args):
    cases = {c["id"]: c for c in load_cases(lab)}
    runs = load_runs(lab)
    rows = []
    print(f"Lab {lab}: reading back {len(runs)} recorded instance(s)")
    for cid, case in cases.items():
        key = runs.get(cid)
        if not key:
            rows.append((cid, case["title"], "-", "not started", "-", "NOT RUN"))
            continue
        obs = observe(key, args)
        verdict, detail = judge(case, obs)
        rows.append((cid, case["title"], key, obs["state"], detail, verdict))
        print(f"  {cid}: {verdict:8} {detail}")
    out = os.path.join(REPO, LABS[lab]["dir"], "docs", "test-results.md")
    stamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    with open(out, "w", encoding="utf-8") as fh:
        fh.write(f"# Lab {lab} - test results\n\nCollected from the running Camunda 8 cluster on {stamp} "
                 f"with `scripts/run_test_cases.py {lab} --collect`.\n\n"
                 "| ID | Scenario | Process instance key | Observed state | Observed outcome | Status |\n"
                 "|---|---|---|---|---|---|\n")
        for r in rows:
            fh.write("| " + " | ".join(str(c).replace("|", "/") for c in r) + " |\n")
        fh.write("\nStatus meaning: PASS = matches the expected end state; WAITING = stopped at the expected "
                 "human task / incident (finish it and collect again); FAIL / ERROR = investigate in Operate.\n")
    print(f"Wrote {out}")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("lab", type=int, choices=sorted(LABS))
    ap.add_argument("--case", help="run / collect a single test case id, e.g. TC-L1-07")
    ap.add_argument("--collect", action="store_true", help="read results back and write docs/test-results.md")
    ap.add_argument("--recover", action="store_true", help="switch all failure switches OFF")
    ap.add_argument("--base-url", default="http://localhost:8080", help="Camunda REST address")
    ap.add_argument("--user")
    ap.add_argument("--password")
    args = ap.parse_args()

    if args.recover:
        set_switches(args.lab, {}, args)
        print("All failure switches are OFF. Now retry the incident(s) in Operate.")
        return
    if args.collect:
        collect(args.lab, args)
        return

    cases = load_cases(args.lab)
    if args.case:
        cases = [c for c in cases if c["id"] == args.case]
        if not cases:
            sys.exit(f"Unknown case {args.case}")
    else:
        cases = [c for c in cases if c["expect"]["kind"] != "incident"]
        print("Starting all non-incident cases (run incident cases one by one with --case).")
    runs = load_runs(args.lab)
    for case in cases:
        key = start_case(args.lab, case, args)
        if key:
            runs[case["id"]] = key
    with open(runs_path(args.lab), "w", encoding="utf-8") as fh:
        json.dump(runs, fh, indent=2)
    print("Next: complete human tasks in Tasklist, inspect Operate, then run with --collect.")


if __name__ == "__main__":
    main()
