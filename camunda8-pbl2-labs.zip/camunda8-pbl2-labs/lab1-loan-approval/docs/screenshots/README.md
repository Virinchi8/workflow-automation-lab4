# Lab 1 - screenshots (evidence)

The assignment requires screenshots captured **from your own running implementation**. This folder is intentionally empty: take the screenshots listed below while you run the lab and save them here with these exact file names so the report links match. Do not submit placeholder images.

| File | What to capture | Where |
|---|---|---|
| 01-bpmn-model.png | The BPMN diagram open in Camunda Modeler (whole process visible) | Modeler |
| 02-dmn-table.png | The `loanEligibility` decision table | Modeler |
| 03-rest-connector-config.png | Properties panel of the *Credit assessment* task (type `io.camunda:http-json:1`, URL, body, result/error expression) | Modeler |
| 04-worker-running.png | Terminal showing the Spring Boot application started and the deployment log | Terminal |
| 05-operate-processes.png | Operate -> Processes showing `loan-approval` deployed with several instances | Operate |
| 06-operate-approved-instance.png | Operate: completed instance TC-L1-01 with the visited path highlighted | Operate |
| 07-operate-variables.png | Operate: Variables tab of an instance (validationPassed, creditScore, eligibility, finalStatus) | Operate |
| 08-tasklist-manual-review.png | Tasklist: the *Manual loan review* task with its form (TC-L1-04) | Tasklist |
| 09-operate-credit-api-error.png | Operate: TC-L1-05 instance routed via the boundary event | Operate |
| 10-operate-incident.png | Operate: incident on *Validate applicant* (TC-L1-07) with the error message | Operate |
| 11-incident-fixed-retry.png | Operate: the same incident after `--recover` and clicking *Retry* (incident resolved) | Operate |
| 12-operate-recovered-instance.png | Operate: TC-L1-07 instance completed after recovery | Operate |

Tick each item once the file exists:

- [ ] `01-bpmn-model.png`
- [ ] `02-dmn-table.png`
- [ ] `03-rest-connector-config.png`
- [ ] `04-worker-running.png`
- [ ] `05-operate-processes.png`
- [ ] `06-operate-approved-instance.png`
- [ ] `07-operate-variables.png`
- [ ] `08-tasklist-manual-review.png`
- [ ] `09-operate-credit-api-error.png`
- [ ] `10-operate-incident.png`
- [ ] `11-incident-fixed-retry.png`
- [ ] `12-operate-recovered-instance.png`
