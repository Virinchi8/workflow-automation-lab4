# Lab 1 - process-variable dictionary

| Variable | Type | Set by | Purpose |
|---|---|---|---|
| applicantId | string | start form / API | Synthetic applicant reference (e.g. `APP-1001-GOOD`); the suffix steers the mock credit score |
| applicantName | string | start form / API | Synthetic name |
| age | number | start form / API | Applicant age (valid range 21-65) |
| employmentType | string | start form / API | `SALARIED`, `SELF_EMPLOYED` or `UNEMPLOYED` |
| monthlyIncome | number | start form / API | Monthly income in INR |
| existingMonthlyObligations | number | start form / API | Existing EMIs and obligations per month |
| loanAmount | number | start form / API | Requested amount (50 000 - 5 000 000) |
| tenureMonths | number | start form / API | Requested tenure (6-360 months) |
| loanPurpose | string | start form / API | Free text |
| validationPassed | boolean | worker `validate-applicant` | Routing flag for gateway *Application valid?* |
| validationErrors | list of string | worker `validate-applicant` | Reasons when validation fails |
| estimatedEmi | number | worker `validate-applicant` | Reducing-balance EMI at the fixed 10 % illustrative rate |
| obligationRatio | number | worker `validate-applicant` | (EMI + existing obligations) / monthly income - DMN input |
| loanToIncomeMultiple | number | worker `validate-applicant` | loanAmount / monthlyIncome |
| creditScore | number | REST connector (result expression) | Score from the mock credit API (DMN input) |
| creditRating | string | REST connector | EXCELLENT / GOOD / FAIR / POOR |
| activeLoans | number | REST connector | Number of active loans reported by the mock bureau |
| creditCheckStatus | string | REST connector / BPMN error | `COMPLETED`, or `UNAVAILABLE` when the API failed |
| creditCheckError | string | BPMN error (boundary event) | HTTP status code of the failed call |
| eligibility | context | DMN `loanEligibility` | `{decision, reason}`; `decision` is Approved / Rejected / Manual Review |
| reviewDecision | string | form `loan-manual-review` | `APPROVED` or `REJECTED` (gateway *Reviewer decision*) |
| reviewerComments | string | form `loan-manual-review` | Free text from the loan officer |
| finalStatus | string | script task | `APPROVED`, `REJECTED`, `REJECTED_INVALID`, `APPROVED_AFTER_REVIEW`, `REJECTED_AFTER_REVIEW` |
