# Lab 1 - REST connector configuration and API examples

## REST connector configuration

Task **Credit assessment (POST /mock/credit-assessment)** in `bpmn/loan-approval.bpmn`. In Camunda Modeler this appears as a service task with the REST outbound connector settings below (select the task -> *Input / Output* and *Headers* in the properties panel, or apply the *REST Outbound Connector* template).

| Setting | Value |
|---|---|
| Task definition type | `io.camunda:http-json:1` (REST outbound connector) |
| Authentication | `noAuth` (input `authentication.type`) |
| Method / URL | `POST` `http://localhost:8081/mock/credit-assessment` |
| Body (FEEL) | `={applicantId: applicantId, monthlyIncome: monthlyIncome, loanAmount: loanAmount}` |
| Timeouts | connection 5 s, read 5 s |
| Result expression | `={creditScore: response.body.creditScore, creditRating: response.body.rating, activeLoans: response.body.activeLoans, creditCheckStatus: "COMPLETED"}` |
| Error expression | `=if matches(error.code, "5[0-9][0-9]") then bpmnError("CREDIT_SERVICE_ERROR", "Credit bureau API error " + error.code, {creditCheckStatus: "UNAVAILABLE", creditCheckError: error.code}) else null` |
| Retries / backoff | retries = 1 (`zeebe:taskDefinition`), `retryBackoff = PT0S` |

## Request / response examples

All examples run against the mock API of this lab (worker application on port 8081); they work without Camunda.

### 1. Credit assessment - success (HTTP 200)

```bash
curl -s -X POST http://localhost:8081/mock/credit-assessment \
  -H 'Content-Type: application/json' \
  -d '{"applicantId":"APP-1001-GOOD","monthlyIncome":100000,"loanAmount":500000}'
```

```json
{"applicantId":"APP-1001-GOOD","creditScore":780,"rating":"EXCELLENT","activeLoans":2,"assessedAt":"2026-11-06T09:30:00Z"}
```

`activeLoans` and `assessedAt` vary; the score is deterministic (`-GOOD` 780, `-FAIR` 660, `-POOR` 520).

### 2. Credit assessment - API error (HTTP 503)

```bash
curl -s -i -X POST http://localhost:8081/mock/credit-assessment \
  -H 'Content-Type: application/json' \
  -d '{"applicantId":"APP-1005-ERR","monthlyIncome":100000,"loanAmount":500000}'
```

```json
{"error":"CREDIT_BUREAU_UNAVAILABLE"}
```

### 3. Failure switches (admin API)

```bash
curl -s http://localhost:8081/admin/switches
curl -s -X POST 'http://localhost:8081/admin/switches/worker-failure?enabled=true'
curl -s -X POST 'http://localhost:8081/admin/switches/credit-timeout?enabled=true'
curl -s -X POST  http://localhost:8081/admin/reset
```

### 4. Start a process instance (Camunda REST API v2)

```bash
curl -s -X POST http://localhost:8080/v2/process-instances \
  -H 'Content-Type: application/json' \
  -d '{"processDefinitionId":"loan-approval","variables":{
        "applicantId":"APP-1001-GOOD","applicantName":"Asha Rao (synthetic)","age":32,
        "employmentType":"SALARIED","monthlyIncome":100000,"existingMonthlyObligations":5000,
        "loanAmount":500000,"tenureMonths":60,"loanPurpose":"Home renovation"}}'
```

Response: `{"processDefinitionId":"loan-approval","processDefinitionKey":"...","processInstanceKey":"..."}`
