# Loan eligibility decision table

Decision table file: `dmn/loan-eligibility.dmn`  
Hit policy: **FIRST** (the first rule, top to bottom, whose conditions all match wins).  
A dash (`-`) means "any value".

## Inputs and outputs

| # | Input | FEEL input expression |
|---|---|---|
| 1 | Employment type | `employmentType` |
| 2 | Credit score | `creditScore` |
| 3 | Obligation ratio (EMI + existing / income) | `obligationRatio` |
| 4 | Loan-to-income multiple | `loanAmount / monthlyIncome` |

| # | Output name | Label |
|---|---|---|
| 1 | decision | Decision |
| 2 | reason | Reason |

## Rules

| Rule | Employment type | Credit score | Obligation ratio (EMI + existing / income) | Loan-to-income multiple | -> decision | -> reason |
|---|---|---|---|---|---|---|
| R1 - No stable income source | `"UNEMPLOYED"` | `-` | `-` | `-` | `"Rejected"` | `"No stable income source"` |
| R2 - Credit score below minimum | `-` | `< 550` | `-` | `-` | `"Rejected"` | `"Credit score below minimum of 550"` |
| R3 - Obligations too high | `-` | `-` | `> 0.6` | `-` | `"Rejected"` | `"Total obligations exceed 60% of monthly income"` |
| R4 - Amount too large for income | `-` | `-` | `-` | `> 60` | `"Rejected"` | `"Requested amount exceeds 60x monthly income"` |
| R5 - Strong profile | `-` | `>= 700` | `<= 0.4` | `<= 40` | `"Approved"` | `"Strong credit and affordable repayment"` |
| R6 - Everything else | `-` | `-` | `-` | `-` | `"Manual Review"` | `"Borderline profile - loan officer review required"` |

## Sample evaluations

Evaluated against the rules in the `.dmn` file above (not typed by hand).

| Scenario | Inputs | Matched rule | Result | Detail |
|---|---|---|---|---|
| Unemployed applicant | UNEMPLOYED, score 780, ratio 0.2307, LTI 5.0 | R1 | Rejected | No stable income source |
| Score 520 | SALARIED, score 520, ratio 0.146, LTI 3.8 | R2 | Rejected | Credit score below minimum of 550 |
| Heavy obligations | SALARIED, score 780, ratio 0.984, LTI 15.0 | R3 | Rejected | Total obligations exceed 60% of monthly income |
| Loan 65x income | SALARIED, score 780, ratio 0.5704, LTI 65.0 | R4 | Rejected | Requested amount exceeds 60x monthly income |
| Strong profile | SALARIED, score 780, ratio 0.1562, LTI 5.0 | R5 | Approved | Strong credit and affordable repayment |
| Fair score, high EMI | SALARIED, score 660, ratio 0.5583, LTI 20.0 | R6 | Manual Review | Borderline profile - loan officer review required |
| Good score but ratio above 0.40 | SALARIED, score 780, ratio 0.4125, LTI 10.0 | R6 | Manual Review | Borderline profile - loan officer review required |
