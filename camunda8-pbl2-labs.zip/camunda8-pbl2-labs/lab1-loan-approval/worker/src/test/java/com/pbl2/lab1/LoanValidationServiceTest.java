package com.pbl2.lab1;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.pbl2.lab1.service.CreditScoringService;
import com.pbl2.lab1.service.LoanValidationService;
import java.util.HashMap;
import java.util.Map;
import org.junit.jupiter.api.Test;

class LoanValidationServiceTest {

    private final LoanValidationService service = new LoanValidationService();
    private final CreditScoringService scoring = new CreditScoringService();

    private Map<String, Object> application() {
        Map<String, Object> v = new HashMap<>();
        v.put("applicantId", "APP-1001-GOOD");
        v.put("applicantName", "Asha Rao (synthetic)");
        v.put("age", 32);
        v.put("employmentType", "SALARIED");
        v.put("monthlyIncome", 100000);
        v.put("existingMonthlyObligations", 5000);
        v.put("loanAmount", 500000);
        v.put("tenureMonths", 60);
        return v;
    }

    @Test
    void validApplicationPassesAndComputesRatios() {
        LoanValidationService.Result r = service.validate(application());
        assertTrue(r.passed());
        assertEquals(10623.52, r.estimatedEmi(), 0.01);
        assertEquals(0.1562, r.obligationRatio(), 0.0001);
        assertEquals(5.0, r.loanToIncomeMultiple(), 0.001);
    }

    @Test
    void underageApplicantFails() {
        Map<String, Object> v = application();
        v.put("age", 19);
        LoanValidationService.Result r = service.validate(v);
        assertFalse(r.passed());
        assertTrue(r.errors().stream().anyMatch(msg -> msg.contains("age")));
    }

    @Test
    void badReferenceAndAmountAreReported() {
        Map<String, Object> v = application();
        v.put("applicantId", "john smith");
        v.put("loanAmount", 10);
        LoanValidationService.Result r = service.validate(v);
        assertFalse(r.passed());
        assertEquals(2, r.errors().size());
    }

    @Test
    void creditScoresAreDeterministic() {
        assertEquals(780, scoring.assess("APP-1-GOOD").creditScore());
        assertEquals(660, scoring.assess("APP-2-FAIR").creditScore());
        assertEquals(520, scoring.assess("APP-3-POOR").creditScore());
        int first = scoring.assess("APP-4242").creditScore();
        assertEquals(first, scoring.assess("APP-4242").creditScore());
        assertTrue(first >= 400 && first <= 850);
    }

    @Test
    void ratingBands() {
        assertEquals("EXCELLENT", CreditScoringService.ratingFor(780));
        assertEquals("GOOD", CreditScoringService.ratingFor(700));
        assertEquals("FAIR", CreditScoringService.ratingFor(660));
        assertEquals("POOR", CreditScoringService.ratingFor(520));
    }
}
