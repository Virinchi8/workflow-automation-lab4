package com.pbl2.lab1.service;

import org.springframework.stereotype.Component;

/**
 * Deterministic, synthetic credit scoring used by the mock credit-assessment API. Test applicants
 * choose their score through the id: "-GOOD" = 780, "-FAIR" = 660, "-POOR" = 520. Any other id gets
 * a repeatable pseudo-random score in the range 400-850.
 */
@Component
public class CreditScoringService {

    public record Assessment(int creditScore, String rating, int activeLoans) {
    }

    public Assessment assess(String applicantId) {
        int score;
        if (applicantId.contains("-GOOD")) {
            score = 780;
        } else if (applicantId.contains("-FAIR")) {
            score = 660;
        } else if (applicantId.contains("-POOR")) {
            score = 520;
        } else {
            score = 400 + Math.floorMod(applicantId.hashCode(), 451);
        }
        return new Assessment(score, ratingFor(score), Math.floorMod(applicantId.hashCode(), 4));
    }

    public static String ratingFor(int score) {
        if (score >= 750) {
            return "EXCELLENT";
        }
        if (score >= 700) {
            return "GOOD";
        }
        if (score >= 600) {
            return "FAIR";
        }
        return "POOR";
    }
}
