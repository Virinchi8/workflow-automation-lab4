package com.pbl2.lab1;

import io.camunda.client.annotation.Deployment;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Lab 1 - End-to-end loan approval automation - external job workers plus a mock REST API that the REST connector calls.
 *
 * <p>On start-up the BPMN, DMN and form files from ../bpmn, ../dmn and ../forms (copied onto the
 * classpath by the Maven build) are deployed to the Camunda 8 cluster.
 */
@SpringBootApplication
@Deployment(resources = {"classpath*:/bpmn/*.bpmn", "classpath*:/dmn/*.dmn", "classpath*:/forms/*.form"})
public class Lab1Application {

    public static void main(String[] args) {
        SpringApplication.run(Lab1Application.class, args);
    }
}
