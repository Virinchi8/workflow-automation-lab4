package com.pbl2.lab1.api;

import com.pbl2.lab1.config.FailureSwitches;
import java.util.LinkedHashMap;
import java.util.Map;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/** Admin endpoints used during the demo to inject and clear failures. */
@RestController
@RequestMapping("/admin")
public class AdminController {

    private final FailureSwitches switches;

    public AdminController(FailureSwitches switches) {
        this.switches = switches;
    }

    @GetMapping("/switches")
    public Map<String, Boolean> list() {
        return switches.snapshot();
    }

    @PostMapping("/switches/{name}")
    public ResponseEntity<Map<String, Object>> set(@PathVariable String name, @RequestParam boolean enabled) {
        Map<String, Object> body = new LinkedHashMap<>();
        if (!switches.set(name, enabled)) {
            body.put("error", "Unknown switch '" + name + "'. Known switches: " + FailureSwitches.KNOWN);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(body);
        }
        body.put("switch", name);
        body.put("enabled", enabled);
        return ResponseEntity.ok(body);
    }

    @PostMapping("/reset")
    public Map<String, Object> reset() {
        switches.resetAll();
        return Map.of("status", "all failure switches cleared");
    }
}
