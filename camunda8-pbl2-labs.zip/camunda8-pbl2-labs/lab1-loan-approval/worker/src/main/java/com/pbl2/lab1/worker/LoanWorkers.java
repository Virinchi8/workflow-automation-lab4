package com.pbl2.lab1.worker;

import com.pbl2.lab1.config.FailureSwitches;
import com.pbl2.lab1.service.LoanValidationService;
import io.camunda.client.annotation.JobWorker;
import io.camunda.client.api.response.ActivatedJob;
import java.util.LinkedHashMap;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/** External job workers for the loan-approval process. */
@Component
public class LoanWorkers {

    private static final Logger log = LoggerFactory.getLogger(LoanWorkers.class);

    private final LoanValidationService validation;
    private final FailureSwitches switches;

    public LoanWorkers(LoanValidationService validation, FailureSwitches switches) {
        this.validation = validation;
        this.switches = switches;
    }

    /**
     * Job type "validate-applicant": validates the application and returns the result as process
     * variables. The returned map is merged into the process variables when the job completes.
     * Any exception makes the job fail; with retries = 1 in the BPMN this raises an incident.
     */
    @JobWorker(type = "validate-applicant")
    public Map<String, Object> validateApplicant(final ActivatedJob job) {
        if (switches.isOn("worker-failure")) {
            throw new IllegalStateException(
                    "Simulated validation-service failure (failure switch 'worker-failure' is ON)");
        }
        LoanValidationService.Result r = validation.validate(job.getVariablesAsMap());
        log.info("Validated applicant {}: passed={} errors={}",
                job.getVariablesAsMap().get("applicantId"), r.passed(), r.errors());

        Map<String, Object> out = new LinkedHashMap<>();
        out.put("validationPassed", r.passed());
        out.put("validationErrors", r.errors());
        out.put("estimatedEmi", r.estimatedEmi());
        out.put("obligationRatio", r.obligationRatio());
        out.put("loanToIncomeMultiple", r.loanToIncomeMultiple());
        return out;
    }
}
