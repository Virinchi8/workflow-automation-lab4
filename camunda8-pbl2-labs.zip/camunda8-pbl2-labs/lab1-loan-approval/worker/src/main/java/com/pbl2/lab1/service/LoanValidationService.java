package com.pbl2.lab1.service;

import com.pbl2.lab1.util.Vars;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.springframework.stereotype.Component;

/**
 * Business logic behind the "validate-applicant" job worker. It is deliberately free of any Camunda
 * types so that it can be unit tested on its own.
 */
@Component
public class LoanValidationService {

    /** Fixed illustrative interest rate used to estimate the monthly instalment (EMI). */
    public static final double ANNUAL_RATE = 0.10;

    public static final Set<String> EMPLOYMENT_TYPES = Set.of("SALARIED", "SELF_EMPLOYED", "UNEMPLOYED");

    public record Result(boolean passed, List<String> errors, double estimatedEmi,
                         double obligationRatio, double loanToIncomeMultiple) {
    }

    public Result validate(Map<String, Object> v) {
        List<String> errors = new ArrayList<>();

        String id = Vars.str(v, "applicantId");
        if (id == null || !id.matches("APP-[A-Z0-9]+(-[A-Z0-9]+)*")) {
            errors.add("applicantId must be a synthetic reference such as APP-1001");
        }
        String name = Vars.str(v, "applicantName");
        if (name == null || name.isBlank()) {
            errors.add("applicantName is required");
        }
        Double age = Vars.num(v, "age");
        if (age == null || age < 21 || age > 65) {
            errors.add("age must be between 21 and 65");
        }
        String employment = Vars.str(v, "employmentType");
        if (employment == null || !EMPLOYMENT_TYPES.contains(employment)) {
            errors.add("employmentType must be one of " + EMPLOYMENT_TYPES);
        }
        Double income = Vars.num(v, "monthlyIncome");
        if (income == null || income <= 0) {
            errors.add("monthlyIncome must be greater than 0");
        }
        Double obligations = Vars.num(v, "existingMonthlyObligations");
        if (obligations == null) {
            obligations = 0.0;
        }
        if (obligations < 0) {
            errors.add("existingMonthlyObligations cannot be negative");
        }
        Double loan = Vars.num(v, "loanAmount");
        if (loan == null || loan < 50_000 || loan > 5_000_000) {
            errors.add("loanAmount must be between 50000 and 5000000");
        }
        Double tenure = Vars.num(v, "tenureMonths");
        if (tenure == null || tenure < 6 || tenure > 360 || tenure != Math.floor(tenure)) {
            errors.add("tenureMonths must be a whole number between 6 and 360");
        }

        if (!errors.isEmpty()) {
            return new Result(false, errors, 0, 0, 0);
        }
        double emi = estimateEmi(loan, tenure.intValue());
        double ratio = round((emi + obligations) / income, 4);
        double multiple = round(loan / income, 2);
        return new Result(true, errors, emi, ratio, multiple);
    }

    /** Standard reducing-balance EMI formula: P * r * (1+r)^n / ((1+r)^n - 1). */
    public static double estimateEmi(double principal, int months) {
        double r = ANNUAL_RATE / 12;
        double growth = Math.pow(1 + r, months);
        return round(principal * r * growth / (growth - 1), 2);
    }

    private static double round(double value, int places) {
        double f = Math.pow(10, places);
        return Math.round(value * f) / f;
    }
}
