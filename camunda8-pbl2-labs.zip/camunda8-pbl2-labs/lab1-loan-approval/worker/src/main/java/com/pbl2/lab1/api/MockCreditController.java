package com.pbl2.lab1.api;

import com.pbl2.lab1.config.FailureSwitches;
import com.pbl2.lab1.service.CreditScoringService;
import com.pbl2.lab1.util.Vars;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Mock credit-bureau API called by the REST connector (POST /mock/credit-assessment).
 *
 * <ul>
 *   <li>applicantId containing "-ERR" always answers HTTP 503 (API error scenario).</li>
 *   <li>With the "credit-timeout" switch ON every call stalls for 15 s, longer than the connector's
 *       5 s read timeout (timeout scenario - produces an incident in Operate).</li>
 * </ul>
 */
@RestController
@RequestMapping("/mock")
public class MockCreditController {

    private static final Logger log = LoggerFactory.getLogger(MockCreditController.class);

    private final CreditScoringService scoring;
    private final FailureSwitches switches;

    public MockCreditController(CreditScoringService scoring, FailureSwitches switches) {
        this.scoring = scoring;
        this.switches = switches;
    }

    @PostMapping("/credit-assessment")
    public ResponseEntity<Map<String, Object>> assess(@RequestBody Map<String, Object> request)
            throws InterruptedException {
        String id = Vars.str(request, "applicantId");
        Map<String, Object> body = new LinkedHashMap<>();
        if (id == null || id.isBlank()) {
            body.put("error", "applicantId is required");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(body);
        }
        log.info("Credit assessment requested for {}", id);
        if (id.contains("-ERR")) {
            body.put("error", "CREDIT_BUREAU_UNAVAILABLE");
            return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(body);
        }
        if (switches.isOn("credit-timeout")) {
            log.warn("Switch 'credit-timeout' is ON - stalling the response");
            Thread.sleep(15_000);
        }
        CreditScoringService.Assessment a = scoring.assess(id);
        body.put("applicantId", id);
        body.put("creditScore", a.creditScore());
        body.put("rating", a.rating());
        body.put("activeLoans", a.activeLoans());
        body.put("assessedAt", Instant.now().toString());
        return ResponseEntity.ok(body);
    }
}
