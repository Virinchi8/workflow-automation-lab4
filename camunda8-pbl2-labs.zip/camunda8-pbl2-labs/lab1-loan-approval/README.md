# Lab 1 - End-to-End Loan Approval Automation

## Contents

| Path | What it is |
|---|---|
| bpmn/loan-approval.bpmn | BPMN process `loan-approval` |
| dmn/loan-eligibility.dmn | DMN decision table |
| forms/ | Camunda Forms for the start form and the user tasks |
| worker/ | Spring Boot application: job workers + mock REST API (port 8081) + unit tests |
| test-data/test-cases.json | Machine-readable test cases used by `scripts/run_test_cases.py` |
| REPORT.md | Implementation report |
| docs/ | process-variables, DMN rules, REST/API examples, test cases, screenshots checklist |

## Run it

1. Start a local Camunda 8 cluster (see [../docs/SETUP.md](../docs/SETUP.md)).
2. Start the worker application (deploys the models automatically):

```bash
cd worker
mvn spring-boot:run
```
3. Open Tasklist / Operate (`http://localhost:8080/tasklist`, `http://localhost:8080/operate`, login `demo` / `demo`).
4. Start instances - either with the *End* start form in Tasklist -> Processes, or:

```bash
python ../scripts/run_test_cases.py 1              # all non-incident cases
python ../scripts/run_test_cases.py 1 --case TC-L1-08   # one case (an incident case)
python ../scripts/run_test_cases.py 1 --recover            # switch failures OFF, then Retry in Operate
python ../scripts/run_test_cases.py 1 --collect            # write docs/test-results.md
```
5. Complete the human tasks in Tasklist, inspect the instances in Operate and capture the screenshots listed in [docs/screenshots/README.md](docs/screenshots/README.md).

Unit tests of the business logic (no Camunda needed): `cd worker && mvn test`.
