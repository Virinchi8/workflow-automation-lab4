# Lab 1 - End-to-End Loan Approval Automation

**Course:** PBL-II - Camunda 8 workflow automation  
**Student:** _your name_  **Register no.:** _your register number_  
**Date:** _submission date_

## 1. Objective

Implement the *End-to-End Loan Approval Automation* workflow on Camunda 8 using BPMN for orchestration, a DMN decision table for the business rules, Spring Boot external job workers, a REST connector calling a mock service, Tasklist for human work, and Operate for monitoring and incident recovery. All data is synthetic.

## 2. Architecture

```mermaid
flowchart LR
  M[Camunda Modeler<br/>BPMN, DMN, forms] -- deploy --> Z
  subgraph C8[Camunda 8 cluster]
    Z[Zeebe engine]
    O[Operate]
    T[Tasklist]
    CR[Connectors runtime<br/>REST connector]
  end
  Z <-- job workers poll / complete --> W[Spring Boot application :8081<br/>job workers]
  CR -- HTTP --> API[Mock REST API<br/>same Spring Boot application]
  U[Staff user] --> T
  Z --> O
```

* **Models** - `bpmn/loan-approval.bpmn`, `dmn/loan-eligibility.dmn`, `forms/*.form`; deployed automatically when the Spring Boot application starts (`@Deployment`) or manually from Camunda Modeler.
* **Worker application** (`worker/`, package `com.pbl2.lab1`) - hosts the job workers and the mock REST API so that one process runs everything locally.
* **REST connector** - a service task of type `io.camunda:http-json:1`, executed by the connectors runtime of the cluster.
* **Failure switches** - runtime flags (`/admin/switches`) used to cause and then repair failures for the incident scenarios.

## 3. Process design and execution flow

```mermaid
flowchart TD
    S([Loan application received]) --> V[Validate applicant<br/>worker: validate-applicant]
    V --> G1{Application valid?}
    G1 -- No --> RI([Rejected: invalid application])
    G1 -- Yes --> CA[Credit assessment<br/>REST connector]
    CA -- HTTP 5xx / BPMN error --> MR
    CA --> D[Evaluate loan eligibility<br/>DMN loanEligibility]
    D --> G2{Eligibility decision}
    G2 -- Approved --> A([Loan approved])
    G2 -- Rejected --> R([Loan rejected])
    G2 -- Manual Review --> MR[Manual loan review<br/>user task]
    MR --> G3{Reviewer decision}
    G3 -- Approve --> AR([Approved after review])
    G3 -- Reject --> RR([Rejected after review])
```

### Gateway routing

| Gateway / event | Condition | Route |
|---|---|---|
| Application valid? | `validationPassed = false` | No -> Mark REJECTED_INVALID -> *Rejected: invalid application* |
| Application valid? | default | Yes -> Credit assessment (REST connector) |
| Boundary event *Credit API error* | BPMN error `CREDIT_SERVICE_ERROR` raised by the connector's `errorExpression` for HTTP 5xx | -> Manual loan review |
| Eligibility decision | `eligibility.decision = "Approved"` | -> Mark APPROVED -> *Loan approved* |
| Eligibility decision | `eligibility.decision = "Rejected"` | -> Mark REJECTED -> *Loan rejected* |
| Eligibility decision | default (Manual Review) | -> Manual loan review (user task) |
| Reviewer decision | `reviewDecision = "APPROVED"` | -> Mark APPROVED_AFTER_REVIEW -> *Approved after review* |
| Reviewer decision | default | -> Mark REJECTED_AFTER_REVIEW -> *Rejected after review* |

## 4. Decision model (DMN)

See [docs/dmn-rules.md](docs/dmn-rules.md) for the inputs, outputs, every rule and sample evaluations. The decision is invoked by a business rule task and its result is stored in a process variable that the following gateway reads.

## 5. Implementation

### External job workers

| Job type | Method | Purpose |
|---|---|---|
| validate-applicant | `LoanWorkers.validateApplicant` | Validates the application fields, estimates the EMI and computes the obligation ratio and loan-to-income multiple. |

Workers return a `Map` that Camunda merges into the process variables when the job completes. Throwing an exception fails the job; the BPMN sets `retries="1"`, so a single failure creates an incident that can be retried from Operate after the cause is fixed.

### REST connector

| Setting | Value |
|---|---|
| Task definition type | `io.camunda:http-json:1` (REST outbound connector) |
| Authentication | `noAuth` (input `authentication.type`) |
| Method / URL | `POST` `http://localhost:8081/mock/credit-assessment` |
| Body (FEEL) | `={applicantId: applicantId, monthlyIncome: monthlyIncome, loanAmount: loanAmount}` |
| Timeouts | connection 5 s, read 5 s |
| Result expression | `={creditScore: response.body.creditScore, creditRating: response.body.rating, activeLoans: response.body.activeLoans, creditCheckStatus: "COMPLETED"}` |
| Error expression | `=if matches(error.code, "5[0-9][0-9]") then bpmnError("CREDIT_SERVICE_ERROR", "Credit bureau API error " + error.code, {creditCheckStatus: "UNAVAILABLE", creditCheckError: error.code}) else null` |
| Retries / backoff | retries = 1 (`zeebe:taskDefinition`), `retryBackoff = PT0S` |

### Forms (Tasklist)

| Form id | Used for |
|---|---|
| loan-application-start | Start form in Tasklist - Processes |
| loan-manual-review | Manual review user task |

### Process variables

The complete dictionary (name, type, producer, purpose) is in [docs/process-variables.md](docs/process-variables.md).

## 6. Test scenarios and results

The test-case table with inputs, expected route, actual outcome and status is in [docs/test-cases.md](docs/test-cases.md). Results read back from the running cluster are written to `docs/test-results.md` by `scripts/run_test_cases.py`. The screenshots listed in [docs/screenshots/README.md](docs/screenshots/README.md) are the evidence for deployment, Tasklist work and Operate monitoring.

**Status of evidence:** _fill in after running - results table pasted / linked, screenshots added to `docs/screenshots/`._

## 7. Incident investigation and recovery

Failure switches available in this lab:

| Switch | Effect |
|---|---|
| worker-failure | `validate-applicant` throws -> incident on **Validate applicant** |
| credit-timeout | mock credit API stalls 15 s (> 5 s read timeout) -> incident on **Credit assessment** |

Procedure used for each incident scenario:

1. Turn the switch ON (`scripts/run_test_cases.py 1 --case <id>` does this) and start the instance.
2. In **Operate** open the instance, select the failed element and read the incident error message (screenshot).
3. Fix the cause: `python scripts/run_test_cases.py 1 --recover` (or call the admin endpoint).
4. In Operate press **Retry** on the incident; the job is re-activated, succeeds and the instance continues to its end event (screenshots).

## 8. Assumptions and limitations

* All business rules, thresholds, prices and interest rates are illustrative values chosen for the exercise.
* The mock APIs keep state in memory only; restarting the worker application resets it.
* Failure switches are a teaching aid - a real service would fail for real reasons.
* Authentication is disabled (local Camunda 8 Run); a production setup would secure the cluster, the worker credentials and the APIs.
* The REST connector calls `localhost`; this works when the connectors runtime runs on the same machine as the worker application (Camunda 8 Run). With Docker Compose use `host.docker.internal` in the URL.
* Retries are set to 1 so incidents appear immediately; production processes would use retries with back-off.

## 9. How to run

See [README.md](README.md) in this folder and [../docs/SETUP.md](../docs/SETUP.md).
