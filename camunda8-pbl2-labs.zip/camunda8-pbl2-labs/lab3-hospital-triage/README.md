# Lab 3 - End-to-End Hospital Appointment and Patient Triage Management

> **Educational scenario only.** The triage rules in this lab are simplified teaching rules for a workflow exercise. They are not clinical guidance and must not be used for real patients. Use synthetic data only.


## Contents

| Path | What it is |
|---|---|
| bpmn/patient-triage.bpmn | BPMN process `patient-triage` |
| dmn/triage-classification.dmn | DMN decision table |
| forms/ | Camunda Forms for the start form and the user tasks |
| worker/ | Spring Boot application: job workers + mock REST API (port 8083) + unit tests |
| test-data/test-cases.json | Machine-readable test cases used by `scripts/run_test_cases.py` |
| REPORT.md | Implementation report |
| docs/ | process-variables, DMN rules, REST/API examples, test cases, screenshots checklist |

## Run it

1. Start a local Camunda 8 cluster (see [../docs/SETUP.md](../docs/SETUP.md)).
2. Start the worker application (deploys the models automatically):

```bash
cd worker
mvn spring-boot:run
```
3. Open Tasklist / Operate (`http://localhost:8080/tasklist`, `http://localhost:8080/operate`, login `demo` / `demo`).
4. Start instances - either with the *End* start form in Tasklist -> Processes, or:

```bash
python ../scripts/run_test_cases.py 3              # all non-incident cases
python ../scripts/run_test_cases.py 3 --case TC-L3-07   # one case (an incident case)
python ../scripts/run_test_cases.py 3 --recover            # switch failures OFF, then Retry in Operate
python ../scripts/run_test_cases.py 3 --collect            # write docs/test-results.md
```
5. Complete the human tasks in Tasklist, inspect the instances in Operate and capture the screenshots listed in [docs/screenshots/README.md](docs/screenshots/README.md).

Unit tests of the business logic (no Camunda needed): `cd worker && mvn test`.
