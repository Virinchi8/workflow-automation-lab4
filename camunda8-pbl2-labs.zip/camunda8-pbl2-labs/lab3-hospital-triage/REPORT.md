# Lab 3 - End-to-End Hospital Appointment and Patient Triage Management

**Course:** PBL-II - Camunda 8 workflow automation  
**Student:** _your name_  **Register no.:** _your register number_  
**Date:** _submission date_

> **Educational scenario only.** The triage rules in this lab are simplified teaching rules for a workflow exercise. They are not clinical guidance and must not be used for real patients. Use synthetic data only.


## 1. Objective

Implement the *End-to-End Hospital Appointment and Patient Triage Management* workflow on Camunda 8 using BPMN for orchestration, a DMN decision table for the business rules, Spring Boot external job workers, a REST connector calling a mock service, Tasklist for human work, and Operate for monitoring and incident recovery. All data is synthetic.

## 2. Architecture

```mermaid
flowchart LR
  M[Camunda Modeler<br/>BPMN, DMN, forms] -- deploy --> Z
  subgraph C8[Camunda 8 cluster]
    Z[Zeebe engine]
    O[Operate]
    T[Tasklist]
    CR[Connectors runtime<br/>REST connector]
  end
  Z <-- job workers poll / complete --> W[Spring Boot application :8083<br/>job workers]
  CR -- HTTP --> API[Mock REST API<br/>same Spring Boot application]
  U[Staff user] --> T
  Z --> O
```

* **Models** - `bpmn/patient-triage.bpmn`, `dmn/triage-classification.dmn`, `forms/*.form`; deployed automatically when the Spring Boot application starts (`@Deployment`) or manually from Camunda Modeler.
* **Worker application** (`worker/`, package `com.pbl2.lab3`) - hosts the job workers and the mock REST API so that one process runs everything locally.
* **REST connector** - a service task of type `io.camunda:http-json:1`, executed by the connectors runtime of the cluster.
* **Failure switches** - runtime flags (`/admin/switches`) used to cause and then repair failures for the incident scenarios.

## 3. Process design and execution flow

```mermaid
flowchart TD
    S([Appointment request received]) --> V[Validate registration<br/>worker: validate-registration]
    V --> G1{Registration valid?}
    G1 -- No --> RR([Registration rejected])
    G1 -- Yes --> D[Classify triage category<br/>DMN triageClassification]
    D --> G2{Triage category}
    G2 -- Urgent Assessment --> U[Immediate human assessment<br/>user task]
    U --> UD([Urgent assessment completed])
    G2 -- Priority Review --> PR[Priority staff review<br/>user task]
    PR --> G3{Proceed to booking?}
    G3 -- Refer --> RF([Referred to specialist])
    G3 -- Proceed --> PA
    G2 -- Routine --> PA[Prepare availability request<br/>worker]
    PA --> GS[Get appointment slots<br/>REST connector]
    GS --> G4{Slots available?}
    G4 -- Yes --> B[Book appointment<br/>worker: book-appointment]
    B --> BK([Appointment booked])
    G4 -- No slots --> SR[Scheduling staff review<br/>user task]
    SR --> SD([Scheduling review completed])
```

### Gateway routing

| Gateway / event | Condition | Route |
|---|---|---|
| Registration valid? | `registrationValid = false` | No -> Mark REGISTRATION_REJECTED -> *Registration rejected* |
| Registration valid? | default | Yes -> Classify triage category (DMN) |
| Triage category | `triage.triageCategory = "Urgent Assessment"` | -> Immediate human assessment (user task) -> *Urgent assessment completed* |
| Triage category | `triage.triageCategory = "Priority Review"` | -> Priority staff review (user task) |
| Triage category | default (Routine) | -> Prepare availability request |
| Proceed to booking? | `reviewOutcome = "PROCEED_TO_BOOKING"` | Proceed -> Prepare availability request |
| Proceed to booking? | default | Refer -> Mark REFERRED_TO_SPECIALIST -> *Referred to specialist* |
| Slots available? | `slotCount > 0` | Yes -> Book appointment -> Mark APPOINTMENT_BOOKED -> *Appointment booked* |
| Slots available? | default | No slots -> Scheduling staff review (user task) -> *Scheduling review completed* |

## 4. Decision model (DMN)

See [docs/dmn-rules.md](docs/dmn-rules.md) for the inputs, outputs, every rule and sample evaluations. The decision is invoked by a business rule task and its result is stored in a process variable that the following gateway reads.

## 5. Implementation

### External job workers

| Job type | Method | Purpose |
|---|---|---|
| validate-registration | `TriageWorkers.validateRegistration` | Validates the registration fields (synthetic patient reference, age, preference, date, indicators) and normalises the indicator list. |
| prepare-availability-request | `TriageWorkers.prepareAvailabilityRequest` | Builds the availability query (date window, part of day) from the triage category and preference. |
| book-appointment | `TriageWorkers.bookAppointment` | Books the first free slot returned by the scheduling API. |

Workers return a `Map` that Camunda merges into the process variables when the job completes. Throwing an exception fails the job; the BPMN sets `retries="1"`, so a single failure creates an incident that can be retried from Operate after the cause is fixed.

### REST connector

| Setting | Value |
|---|---|
| Task definition type | `io.camunda:http-json:1` (REST outbound connector) |
| Authentication | `noAuth` (mock service) |
| Method / URL | `GET` `http://localhost:8083/mock/scheduling/slots` |
| Query parameters (FEEL) | `={patientRef: patientRef, fromDate: availabilityQuery.fromDate, toDate: availabilityQuery.toDate, partOfDay: availabilityQuery.partOfDay, maxResults: availabilityQuery.maxResults}` |
| Timeouts | connection 5 s, read 10 s |
| Result expression | `={availableSlots: response.body.slots, slotCount: count(response.body.slots)}` |
| Error expression | none - an HTTP 5xx response makes the connector job fail, which raises an incident (the *scheduling failure* scenario) |
| Retries / backoff | retries = 1 (`zeebe:taskDefinition`), `retryBackoff = PT0S` |

### Forms (Tasklist)

| Form id | Used for |
|---|---|
| triage-start | Start form in Tasklist - Processes |
| urgent-assessment | Immediate human assessment |
| priority-review | Priority staff review |
| scheduling-review | Scheduling staff review (no slot) |

### Process variables

The complete dictionary (name, type, producer, purpose) is in [docs/process-variables.md](docs/process-variables.md).

## 6. Test scenarios and results

The test-case table with inputs, expected route, actual outcome and status is in [docs/test-cases.md](docs/test-cases.md). Results read back from the running cluster are written to `docs/test-results.md` by `scripts/run_test_cases.py`. The screenshots listed in [docs/screenshots/README.md](docs/screenshots/README.md) are the evidence for deployment, Tasklist work and Operate monitoring.

**Status of evidence:** _fill in after running - results table pasted / linked, screenshots added to `docs/screenshots/`._

## 7. Incident investigation and recovery

Failure switches available in this lab:

| Switch | Effect |
|---|---|
| scheduling-outage | mock scheduling API answers HTTP 503 -> incident on **Get appointment slots** |

Procedure used for each incident scenario:

1. Turn the switch ON (`scripts/run_test_cases.py 3 --case <id>` does this) and start the instance.
2. In **Operate** open the instance, select the failed element and read the incident error message (screenshot).
3. Fix the cause: `python scripts/run_test_cases.py 3 --recover` (or call the admin endpoint).
4. In Operate press **Retry** on the incident; the job is re-activated, succeeds and the instance continues to its end event (screenshots).

## 8. Assumptions and limitations

* All business rules, thresholds, prices and interest rates are illustrative values chosen for the exercise.
* The mock APIs keep state in memory only; restarting the worker application resets it.
* Failure switches are a teaching aid - a real service would fail for real reasons.
* Authentication is disabled (local Camunda 8 Run); a production setup would secure the cluster, the worker credentials and the APIs.
* The REST connector calls `localhost`; this works when the connectors runtime runs on the same machine as the worker application (Camunda 8 Run). With Docker Compose use `host.docker.internal` in the URL.
* Retries are set to 1 so incidents appear immediately; production processes would use retries with back-off.

* The triage rules are an educational simplification and are not a clinical decision tool.

## 9. How to run

See [README.md](README.md) in this folder and [../docs/SETUP.md](../docs/SETUP.md).
