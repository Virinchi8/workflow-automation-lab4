# Lab 3 - REST connector configuration and API examples

## REST connector configuration

Task **Get appointment slots (GET /mock/scheduling/slots)** in `bpmn/patient-triage.bpmn`. In Camunda Modeler this appears as a service task with the REST outbound connector settings below (select the task -> *Input / Output* and *Headers* in the properties panel, or apply the *REST Outbound Connector* template).

| Setting | Value |
|---|---|
| Task definition type | `io.camunda:http-json:1` (REST outbound connector) |
| Authentication | `noAuth` (mock service) |
| Method / URL | `GET` `http://localhost:8083/mock/scheduling/slots` |
| Query parameters (FEEL) | `={patientRef: patientRef, fromDate: availabilityQuery.fromDate, toDate: availabilityQuery.toDate, partOfDay: availabilityQuery.partOfDay, maxResults: availabilityQuery.maxResults}` |
| Timeouts | connection 5 s, read 10 s |
| Result expression | `={availableSlots: response.body.slots, slotCount: count(response.body.slots)}` |
| Error expression | none - an HTTP 5xx response makes the connector job fail, which raises an incident (the *scheduling failure* scenario) |
| Retries / backoff | retries = 1 (`zeebe:taskDefinition`), `retryBackoff = PT0S` |

## Request / response examples

All examples run against the mock scheduling API of this lab (worker application on port 8083); they work without Camunda.
Slot dates are generated relative to today, so the dates below are only an example.

### 1. Available slots (HTTP 200)

```bash
curl -s 'http://localhost:8083/mock/scheduling/slots?patientRef=PAT-1001&fromDate=2026-11-09&toDate=2026-11-10&partOfDay=MORNING&maxResults=2'
```

```json
{"patientRef":"PAT-1001","slots":[
  {"slotId":"SLT-2026-11-09-0900","date":"2026-11-09","time":"09:00","partOfDay":"MORNING","clinic":"General OPD","provider":"Dr. Synthetic"},
  {"slotId":"SLT-2026-11-09-1030","date":"2026-11-09","time":"10:30","partOfDay":"MORNING","clinic":"General OPD","provider":"Dr. Synthetic"}]}
```

### 2. No slots available (HTTP 200, empty list)

```bash
curl -s 'http://localhost:8083/mock/scheduling/slots?patientRef=PAT-1004-NOSLOT&fromDate=2026-11-09&toDate=2026-11-20'
```

```json
{"patientRef":"PAT-1004-NOSLOT","slots":[]}
```

### 3. Scheduling outage (HTTP 503)

```bash
curl -s -X POST 'http://localhost:8083/admin/switches/scheduling-outage?enabled=true'
curl -s -i 'http://localhost:8083/mock/scheduling/slots?patientRef=PAT-1005&fromDate=2026-11-09&toDate=2026-11-10'
```

```json
{"error":"SCHEDULING_SERVICE_UNAVAILABLE"}
```

### 4. Admin API

```bash
curl -s http://localhost:8083/admin/switches
curl -s -X POST http://localhost:8083/admin/bookings/reset
curl -s -X POST http://localhost:8083/admin/reset
```

### 5. Start a process instance (Camunda REST API v2)

```bash
curl -s -X POST http://localhost:8080/v2/process-instances \
  -H 'Content-Type: application/json' \
  -d '{"processDefinitionId":"patient-triage","variables":{
        "patientRef":"PAT-1001","patientAge":34,"appointmentPreference":"MORNING",
        "symptomsSummary":"Mild cough for two days (synthetic)","symptomDurationDays":2,
        "urgencyIndicators":["mild_cough"]}}'
```
