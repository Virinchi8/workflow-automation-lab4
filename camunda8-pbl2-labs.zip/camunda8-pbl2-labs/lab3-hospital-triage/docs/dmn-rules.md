> **Educational scenario only.** The triage rules in this lab are simplified teaching rules for a workflow exercise. They are not clinical guidance and must not be used for real patients. Use synthetic data only.

# Triage classification decision table (educational)

Decision table file: `dmn/triage-classification.dmn`  
Hit policy: **FIRST** (the first rule, top to bottom, whose conditions all match wins).  
A dash (`-`) means "any value".

## Inputs and outputs

| # | Input | FEEL input expression |
|---|---|---|
| 1 | Red-flag indicator count | `count(urgencyIndicators[item = "chest_pain" or item = "breathing_difficulty" or item = "severe_bleeding" or item = "loss_of_consciousness" or item = "stroke_symptoms"])` |
| 2 | Amber indicator count | `count(urgencyIndicators[item = "high_fever" or item = "persistent_vomiting" or item = "severe_headache" or item = "dehydration" or item = "suspected_fracture"])` |
| 3 | Patient age (years) | `patientAge` |
| 4 | Symptom duration (days) | `symptomDurationDays` |

| # | Output name | Label |
|---|---|---|
| 1 | triageCategory | Triage category |
| 2 | rationale | Rationale |

## Rules

| Rule | Red-flag indicator count | Amber indicator count | Patient age (years) | Symptom duration (days) | -> triageCategory | -> rationale |
|---|---|---|---|---|---|---|
| R1 - Any red flag | `>= 1` | `-` | `-` | `-` | `"Urgent Assessment"` | `"At least one red-flag indicator present"` |
| R2 - Two or more amber flags | `-` | `>= 2` | `-` | `-` | `"Priority Review"` | `"Two or more amber indicators present"` |
| R3 - One amber flag in a young child or older adult | `-` | `1` | `>= 65, < 5` | `-` | `"Priority Review"` | `"One amber indicator in an infant/young child or older adult"` |
| R4 - Prolonged symptoms | `-` | `-` | `-` | `> 7` | `"Priority Review"` | `"Symptoms persisting for more than 7 days"` |
| R5 - Everything else | `-` | `-` | `-` | `-` | `"Routine"` | `"No red/amber indicators and short symptom duration"` |

## Sample evaluations

Evaluated against the rules in the `.dmn` file above (not typed by hand).

| Scenario | Inputs | Matched rule | Result | Detail |
|---|---|---|---|---|
| Chest pain | red 1, amber 0, age 58, 0 day(s) | R1 | Urgent Assessment | At least one red-flag indicator present |
| Chest pain and fever | red 1, amber 1, age 30, 1 day(s) | R1 | Urgent Assessment | At least one red-flag indicator present |
| Fever + vomiting | red 0, amber 2, age 30, 1 day(s) | R2 | Priority Review | Two or more amber indicators present |
| Single amber flag, age 70 | red 0, amber 1, age 70, 1 day(s) | R3 | Priority Review | One amber indicator in an infant/young child or older adult |
| Single amber flag, age 3 | red 0, amber 1, age 3, 1 day(s) | R3 | Priority Review | One amber indicator in an infant/young child or older adult |
| Single amber flag, age 30 | red 0, amber 1, age 30, 1 day(s) | R5 | Routine | No red/amber indicators and short symptom duration |
| Mild cough for 10 days | red 0, amber 0, age 30, 10 day(s) | R4 | Priority Review | Symptoms persisting for more than 7 days |
| Mild cough for 2 days | red 0, amber 0, age 30, 2 day(s) | R5 | Routine | No red/amber indicators and short symptom duration |
