# Lab 3 - process-variable dictionary

> **Educational scenario only.** The triage rules in this lab are simplified teaching rules for a workflow exercise. They are not clinical guidance and must not be used for real patients. Use synthetic data only.

| Variable | Type | Set by | Purpose |
|---|---|---|---|
| patientRef | string | start form / API | Synthetic patient reference (`PAT-1001`); a `-NOSLOT` suffix makes the mock API return no slots |
| patientAge | number | start form / API | Age in years (0-120) - DMN input |
| appointmentPreference | string | start form / API | `MORNING`, `AFTERNOON` or `ANY` |
| preferredDate | string | start form / API | Optional `YYYY-MM-DD` |
| symptomsSummary | string | start form / API | Synthetic free text (max 500 characters) |
| symptomDurationDays | number | start form / API | Duration of symptoms - DMN input |
| urgencyIndicators | list of string | start form / API, normalised by worker | Predefined indicators (red / amber / mild); counted inside the DMN |
| registrationValid | boolean | worker `validate-registration` | Routing flag for gateway *Registration valid?* |
| validationErrors | list of string | worker `validate-registration` | Reasons when registration is invalid |
| triage | context | DMN `triageClassification` | `{triageCategory, rationale}`; category is Routine / Priority Review / Urgent Assessment |
| assessmentOutcome | string | form `urgent-assessment` | `ADMIT`, `OBSERVE` or `REFER` |
| assessmentNotes | string | form `urgent-assessment` | Free text |
| reviewOutcome | string | form `priority-review` | `PROCEED_TO_BOOKING` or `REFER_TO_SPECIALIST` |
| reviewerNotes | string | form `priority-review` | Free text |
| availabilityQuery | context | worker `prepare-availability-request` | `{fromDate, toDate, partOfDay, maxResults}` - mapped to the connector's query parameters |
| availableSlots | list of context | REST connector (result expression) | Slots returned by the mock scheduling API |
| slotCount | number | REST connector (result expression) | `count(availableSlots)` - routing flag for gateway *Slots available?* |
| bookingStatus | string | worker `book-appointment` | `BOOKED` |
| bookingReference | string | worker `book-appointment` | Generated reference, e.g. `APT-7001` |
| bookedSlot | context | worker `book-appointment` | The slot that was booked |
| schedulingDecision | string | form `scheduling-review` | `MANUAL_BOOKING` or `WAITLIST` |
| schedulingNotes | string | form `scheduling-review` | Free text |
| finalStatus | string | script task | `APPOINTMENT_BOOKED`, `URGENT_ASSESSMENT_COMPLETED`, `REFERRED_TO_SPECIALIST`, `WAITLISTED`, `MANUALLY_BOOKED`, `REGISTRATION_REJECTED` |
