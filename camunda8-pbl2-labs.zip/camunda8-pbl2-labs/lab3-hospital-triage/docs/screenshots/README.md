# Lab 3 - screenshots (evidence)

The assignment requires screenshots captured **from your own running implementation**. This folder is intentionally empty: take the screenshots listed below while you run the lab and save them here with these exact file names so the report links match. Do not submit placeholder images.

| File | What to capture | Where |
|---|---|---|
| 01-bpmn-model.png | The BPMN diagram open in Camunda Modeler | Modeler |
| 02-dmn-triage-table.png | The `triageClassification` decision table | Modeler |
| 03-rest-connector-config.png | Properties panel of the *Get appointment slots* task | Modeler |
| 04-worker-running.png | Terminal showing the Spring Boot application started and deployment log | Terminal |
| 05-operate-processes.png | Operate -> Processes showing `patient-triage` with several instances | Operate |
| 06-operate-booked-instance.png | Operate: completed instance TC-L3-01 (routine, slot booked) | Operate |
| 07-tasklist-priority-review.png | Tasklist: *Priority staff review* task and form (TC-L3-02) | Tasklist |
| 08-tasklist-urgent-assessment.png | Tasklist: *Immediate human assessment* task (TC-L3-03) | Tasklist |
| 09-tasklist-scheduling-review.png | Tasklist: *Scheduling staff review* task (TC-L3-04, no slots) | Tasklist |
| 10-operate-variables.png | Operate: Variables tab (triage, availableSlots, slotCount, bookingReference) | Operate |
| 11-operate-incident.png | Operate: incident on *Get appointment slots* (TC-L3-05) | Operate |
| 12-incident-fixed-retry.png | Operate: incident resolved after `--recover` + *Retry* | Operate |
| 13-operate-recovered-instance.png | Operate: TC-L3-05 completed after recovery | Operate |

Tick each item once the file exists:

- [ ] `01-bpmn-model.png`
- [ ] `02-dmn-triage-table.png`
- [ ] `03-rest-connector-config.png`
- [ ] `04-worker-running.png`
- [ ] `05-operate-processes.png`
- [ ] `06-operate-booked-instance.png`
- [ ] `07-tasklist-priority-review.png`
- [ ] `08-tasklist-urgent-assessment.png`
- [ ] `09-tasklist-scheduling-review.png`
- [ ] `10-operate-variables.png`
- [ ] `11-operate-incident.png`
- [ ] `12-incident-fixed-retry.png`
- [ ] `13-operate-recovered-instance.png`
