package com.pbl2.lab3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.pbl2.lab3.service.AvailabilityRequestService;
import com.pbl2.lab3.service.RegistrationService;
import com.pbl2.lab3.service.SchedulingService;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;

class TriageServicesTest {

    private static final LocalDate TODAY = LocalDate.of(2026, 11, 6);

    private final RegistrationService registration = new RegistrationService();
    private final AvailabilityRequestService availability = new AvailabilityRequestService();
    private final SchedulingService scheduling = new SchedulingService();

    private Map<String, Object> request() {
        Map<String, Object> v = new HashMap<>();
        v.put("patientRef", "PAT-1001");
        v.put("patientAge", 34);
        v.put("appointmentPreference", "MORNING");
        v.put("symptomsSummary", "Mild cough for two days (synthetic)");
        v.put("symptomDurationDays", 2);
        v.put("urgencyIndicators", List.of("Mild_Cough "));
        return v;
    }

    @Test
    void validRequestNormalisesIndicators() {
        RegistrationService.Result r = registration.validate(request(), TODAY);
        assertTrue(r.valid());
        assertEquals(List.of("mild_cough"), r.urgencyIndicators());
    }

    @Test
    void unknownIndicatorAndBadReferenceAreRejected() {
        Map<String, Object> v = request();
        v.put("patientRef", "john");
        v.put("urgencyIndicators", List.of("made_up"));
        RegistrationService.Result r = registration.validate(v, TODAY);
        assertFalse(r.valid());
        assertEquals(2, r.errors().size());
    }

    @Test
    void pastPreferredDateIsRejected() {
        Map<String, Object> v = request();
        v.put("preferredDate", "2026-11-01");
        assertFalse(registration.validate(v, TODAY).valid());
    }

    @Test
    void priorityRequestsSearchThreeDays() {
        Map<String, Object> q = availability.build("Priority Review", "ANY", null, TODAY);
        assertEquals("2026-11-06", q.get("fromDate"));
        assertEquals("2026-11-08", q.get("toDate"));
    }

    @Test
    void routineRequestsStartTomorrowOrPreferredDate() {
        assertEquals("2026-11-07", availability.build("Routine", "ANY", null, TODAY).get("fromDate"));
        assertEquals("2026-11-20", availability.build("Routine", "ANY", "2026-11-20", TODAY).get("fromDate"));
    }

    @Test
    void slotsRespectPartOfDayAndSkipSundays() {
        List<Map<String, Object>> slots = scheduling.findSlots("PAT-1001", LocalDate.of(2026, 11, 8),
                LocalDate.of(2026, 11, 9), "MORNING", 10);
        assertEquals(3, slots.size());
        for (Map<String, Object> s : slots) {
            assertEquals("2026-11-09", s.get("date"));
            assertEquals("MORNING", s.get("partOfDay"));
        }
        assertEquals(DayOfWeek.MONDAY, LocalDate.parse("2026-11-09").getDayOfWeek());
    }

    @Test
    void noSlotMarkerReturnsEmptyList() {
        assertTrue(scheduling.findSlots("PAT-2002-NOSLOT", TODAY, TODAY.plusDays(14), "ANY", 5).isEmpty());
    }

    @Test
    void bookedSlotsDisappearAndCannotBeBookedTwice() {
        List<Map<String, Object>> before = scheduling.findSlots("PAT-1001", TODAY, TODAY.plusDays(2), "ANY", 5);
        String id = String.valueOf(before.get(0).get("slotId"));
        assertNotNull(scheduling.book(id));
        assertNull(scheduling.book(id));
        List<Map<String, Object>> after = scheduling.findSlots("PAT-1001", TODAY, TODAY.plusDays(2), "ANY", 5);
        assertFalse(after.stream().anyMatch(s -> id.equals(s.get("slotId"))));
    }
}
