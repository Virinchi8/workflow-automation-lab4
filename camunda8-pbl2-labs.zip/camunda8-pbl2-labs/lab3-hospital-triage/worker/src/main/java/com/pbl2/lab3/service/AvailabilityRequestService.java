package com.pbl2.lab3.service;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.LinkedHashMap;
import java.util.Map;
import org.springframework.stereotype.Component;

/** Builds the appointment-availability query that is passed to the scheduling API. */
@Component
public class AvailabilityRequestService {

    /**
     * Priority Review requests look only at the next three days (today to today + 2). Routine requests
     * start from the preferred date (never earlier than tomorrow) and search a 14-day window.
     */
    public Map<String, Object> build(String triageCategory, String preference, String preferredDate, LocalDate today) {
        LocalDate from;
        LocalDate to;
        if ("Priority Review".equals(triageCategory)) {
            from = today;
            to = today.plusDays(2);
        } else {
            LocalDate earliest = today.plusDays(1);
            from = earliest;
            if (preferredDate != null && !preferredDate.isBlank()) {
                try {
                    LocalDate wanted = LocalDate.parse(preferredDate.trim());
                    from = wanted.isAfter(earliest) ? wanted : earliest;
                } catch (DateTimeParseException ignored) {
                    // registration validation has already rejected malformed dates
                }
            }
            to = from.plusDays(13);
        }
        Map<String, Object> query = new LinkedHashMap<>();
        query.put("fromDate", from.toString());
        query.put("toDate", to.toString());
        query.put("partOfDay", preference == null ? "ANY" : preference);
        query.put("maxResults", 5);
        return query;
    }
}
