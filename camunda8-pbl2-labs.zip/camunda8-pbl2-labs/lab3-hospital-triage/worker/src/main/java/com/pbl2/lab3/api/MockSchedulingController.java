package com.pbl2.lab3.api;

import com.pbl2.lab3.config.FailureSwitches;
import com.pbl2.lab3.service.SchedulingService;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Mock hospital scheduling API called by the REST connector (GET /mock/scheduling/slots).
 * With the "scheduling-outage" switch ON it answers HTTP 503 (service failure scenario).
 */
@RestController
@RequestMapping("/mock/scheduling")
public class MockSchedulingController {

    private static final Logger log = LoggerFactory.getLogger(MockSchedulingController.class);

    private final SchedulingService scheduling;
    private final FailureSwitches switches;

    public MockSchedulingController(SchedulingService scheduling, FailureSwitches switches) {
        this.scheduling = scheduling;
        this.switches = switches;
    }

    @GetMapping("/slots")
    public ResponseEntity<Map<String, Object>> slots(@RequestParam String patientRef,
                                                     @RequestParam String fromDate,
                                                     @RequestParam String toDate,
                                                     @RequestParam(defaultValue = "ANY") String partOfDay,
                                                     @RequestParam(defaultValue = "5") int maxResults) {
        Map<String, Object> body = new LinkedHashMap<>();
        if (switches.isOn("scheduling-outage")) {
            log.warn("Switch 'scheduling-outage' is ON - answering 503");
            body.put("error", "SCHEDULING_SERVICE_UNAVAILABLE");
            return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(body);
        }
        LocalDate from;
        LocalDate to;
        try {
            from = LocalDate.parse(fromDate);
            to = LocalDate.parse(toDate);
        } catch (DateTimeParseException e) {
            body.put("error", "fromDate and toDate must be formatted YYYY-MM-DD");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(body);
        }
        if (to.isBefore(from) || from.plusDays(31).isBefore(to)) {
            body.put("error", "date window must be 0-31 days");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(body);
        }
        List<Map<String, Object>> found = scheduling.findSlots(patientRef, from, to, partOfDay,
                Math.max(1, Math.min(maxResults, 20)));
        log.info("Slot search for {} {}..{} {} -> {} slot(s)", patientRef, from, to, partOfDay, found.size());
        body.put("patientRef", patientRef);
        body.put("slots", found);
        return ResponseEntity.ok(body);
    }
}
