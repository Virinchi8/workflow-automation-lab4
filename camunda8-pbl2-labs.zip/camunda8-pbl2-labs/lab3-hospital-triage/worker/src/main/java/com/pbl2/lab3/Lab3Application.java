package com.pbl2.lab3;

import io.camunda.client.annotation.Deployment;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Lab 3 - Hospital appointment and patient triage (educational) - external job workers plus a mock REST API that the REST connector calls.
 *
 * <p>On start-up the BPMN, DMN and form files from ../bpmn, ../dmn and ../forms (copied onto the
 * classpath by the Maven build) are deployed to the Camunda 8 cluster.
 */
@SpringBootApplication
@Deployment(resources = {"classpath*:/bpmn/*.bpmn", "classpath*:/dmn/*.dmn", "classpath*:/forms/*.form"})
public class Lab3Application {

    public static void main(String[] args) {
        SpringApplication.run(Lab3Application.class, args);
    }
}
