package com.pbl2.lab3.worker;

import com.pbl2.lab3.service.AvailabilityRequestService;
import com.pbl2.lab3.service.RegistrationService;
import com.pbl2.lab3.service.SchedulingService;
import com.pbl2.lab3.util.Vars;
import io.camunda.client.annotation.JobWorker;
import io.camunda.client.api.response.ActivatedJob;
import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/** External job workers for the patient-triage process (synthetic, educational data only). */
@Component
public class TriageWorkers {

    private static final Logger log = LoggerFactory.getLogger(TriageWorkers.class);

    private final RegistrationService registration;
    private final AvailabilityRequestService availability;
    private final SchedulingService scheduling;

    public TriageWorkers(RegistrationService registration, AvailabilityRequestService availability,
                         SchedulingService scheduling) {
        this.registration = registration;
        this.availability = availability;
        this.scheduling = scheduling;
    }

    /** Validates the registration fields and normalises the urgency indicators. */
    @JobWorker(type = "validate-registration")
    public Map<String, Object> validateRegistration(final ActivatedJob job) {
        RegistrationService.Result r = registration.validate(job.getVariablesAsMap(), LocalDate.now());
        log.info("Registration for {}: valid={} errors={}", job.getVariablesAsMap().get("patientRef"),
                r.valid(), r.errors());
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("registrationValid", r.valid());
        out.put("validationErrors", r.errors());
        out.put("urgencyIndicators", r.urgencyIndicators());
        return out;
    }

    /** Builds the availability query (date window, part of day) used by the REST connector. */
    @JobWorker(type = "prepare-availability-request")
    public Map<String, Object> prepareAvailabilityRequest(final ActivatedJob job) {
        Map<String, Object> vars = job.getVariablesAsMap();
        String category = Vars.str(Vars.map(vars, "triage"), "triageCategory");
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("availabilityQuery", availability.build(category, Vars.str(vars, "appointmentPreference"),
                Vars.str(vars, "preferredDate"), LocalDate.now()));
        return out;
    }

    /** Books the first free slot returned by the scheduling API. */
    @JobWorker(type = "book-appointment")
    @SuppressWarnings("unchecked")
    public Map<String, Object> bookAppointment(final ActivatedJob job) {
        Object raw = job.getVariablesAsMap().get("availableSlots");
        List<Map<String, Object>> slots = raw instanceof List<?> l ? (List<Map<String, Object>>) l : List.of();
        for (Map<String, Object> slot : slots) {
            String reference = scheduling.book(String.valueOf(slot.get("slotId")));
            if (reference != null) {
                Map<String, Object> out = new LinkedHashMap<>();
                out.put("bookingStatus", "BOOKED");
                out.put("bookingReference", reference);
                out.put("bookedSlot", slot);
                return out;
            }
        }
        throw new IllegalStateException("None of the offered slots could be booked (all already taken)");
    }
}
