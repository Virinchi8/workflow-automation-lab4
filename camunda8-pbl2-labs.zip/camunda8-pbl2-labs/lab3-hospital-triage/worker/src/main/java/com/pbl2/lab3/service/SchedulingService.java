package com.pbl2.lab3.service;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import org.springframework.stereotype.Component;

/**
 * Simulated hospital scheduling back end: generates synthetic OPD slots (Mon-Sat) and keeps track
 * of which ones have been booked. Patient references containing "-NOSLOT" never have availability.
 */
@Component
public class SchedulingService {

    private static final List<String> MORNING = List.of("09:00", "10:30", "11:30");
    private static final List<String> AFTERNOON = List.of("14:00", "15:30", "16:30");

    private final Set<String> booked = ConcurrentHashMap.newKeySet();
    private final AtomicLong references = new AtomicLong(7000);

    public List<Map<String, Object>> findSlots(String patientRef, LocalDate from, LocalDate to,
                                               String partOfDay, int maxResults) {
        List<Map<String, Object>> slots = new ArrayList<>();
        if (patientRef != null && patientRef.contains("-NOSLOT")) {
            return slots;
        }
        for (LocalDate day = from; !day.isAfter(to) && slots.size() < maxResults; day = day.plusDays(1)) {
            if (day.getDayOfWeek() == DayOfWeek.SUNDAY) {
                continue;
            }
            if (!"AFTERNOON".equals(partOfDay)) {
                addSlots(slots, day, "MORNING", MORNING, maxResults);
            }
            if (!"MORNING".equals(partOfDay)) {
                addSlots(slots, day, "AFTERNOON", AFTERNOON, maxResults);
            }
        }
        return slots;
    }

    private void addSlots(List<Map<String, Object>> slots, LocalDate day, String part, List<String> times, int max) {
        for (String time : times) {
            String id = "SLT-" + day + "-" + time.replace(":", "");
            if (slots.size() < max && !booked.contains(id)) {
                Map<String, Object> slot = new LinkedHashMap<>();
                slot.put("slotId", id);
                slot.put("date", day.toString());
                slot.put("time", time);
                slot.put("partOfDay", part);
                slot.put("clinic", "General OPD");
                slot.put("provider", "Dr. Synthetic");
                slots.add(slot);
            }
        }
    }

    /** Marks a slot as booked; returns the booking reference, or null if it was already taken. */
    public String book(String slotId) {
        if (!booked.add(slotId)) {
            return null;
        }
        return "APT-" + references.incrementAndGet();
    }

    public void reset() {
        booked.clear();
    }
}
