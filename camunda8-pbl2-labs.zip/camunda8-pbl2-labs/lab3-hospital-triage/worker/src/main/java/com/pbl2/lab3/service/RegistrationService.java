package com.pbl2.lab3.service;

import com.pbl2.lab3.util.Vars;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.springframework.stereotype.Component;

/**
 * Validates the synthetic registration fields. EDUCATIONAL SCENARIO ONLY - the indicator lists are
 * simplified teaching rules, not clinical guidance, and only synthetic patient data may be used.
 */
@Component
public class RegistrationService {

    public static final Set<String> KNOWN_INDICATORS = Set.of(
            // red flags
            "chest_pain", "breathing_difficulty", "severe_bleeding", "loss_of_consciousness", "stroke_symptoms",
            // amber flags
            "high_fever", "persistent_vomiting", "severe_headache", "dehydration", "suspected_fracture",
            // mild indicators (no triage weight)
            "mild_cough", "sore_throat", "mild_headache", "fatigue", "skin_rash");

    public static final Set<String> PREFERENCES = Set.of("MORNING", "AFTERNOON", "ANY");

    public record Result(boolean valid, List<String> errors, List<String> urgencyIndicators) {
    }

    public Result validate(Map<String, Object> v, LocalDate today) {
        List<String> errors = new ArrayList<>();

        String ref = Vars.str(v, "patientRef");
        if (ref == null || !ref.matches("PAT-\\d{4,}(-[A-Z0-9]+)*")) {
            errors.add("patientRef must be a synthetic reference such as PAT-1001");
        }
        Double age = Vars.num(v, "patientAge");
        if (age == null || age < 0 || age > 120 || age != Math.floor(age)) {
            errors.add("patientAge must be a whole number between 0 and 120");
        }
        String pref = Vars.str(v, "appointmentPreference");
        if (pref == null || !PREFERENCES.contains(pref)) {
            errors.add("appointmentPreference must be one of " + PREFERENCES);
        }
        String preferred = Vars.str(v, "preferredDate");
        if (preferred != null && !preferred.isBlank()) {
            try {
                if (LocalDate.parse(preferred.trim()).isBefore(today)) {
                    errors.add("preferredDate cannot be in the past");
                }
            } catch (DateTimeParseException e) {
                errors.add("preferredDate must be formatted YYYY-MM-DD");
            }
        }
        String summary = Vars.str(v, "symptomsSummary");
        if (summary == null || summary.isBlank() || summary.length() > 500) {
            errors.add("symptomsSummary is required (max 500 characters)");
        }
        Double duration = Vars.num(v, "symptomDurationDays");
        if (duration == null || duration < 0) {
            errors.add("symptomDurationDays must be 0 or more");
        }

        Set<String> indicators = new LinkedHashSet<>();
        for (String raw : Vars.strList(v, "urgencyIndicators")) {
            String key = raw.trim().toLowerCase();
            if (!KNOWN_INDICATORS.contains(key)) {
                errors.add("unknown urgency indicator '" + raw + "'");
            } else {
                indicators.add(key);
            }
        }
        return new Result(errors.isEmpty(), errors, new ArrayList<>(indicators));
    }
}
